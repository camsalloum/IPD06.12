# 🔄 Component Conversion Quick Reference

**Quick guide for converting existing IPD26.10 components to Crema-style Material UI**

---

## 📋 Table Conversion

### **BEFORE: Ant Design Table**
```javascript
import { Table } from 'antd';

const SalesTable = ({ data }) => {
  const columns = [
    { title: 'Country', dataIndex: 'country', key: 'country' },
    { title: 'Sales', dataIndex: 'sales', key: 'sales' },
    { title: 'Growth', dataIndex: 'growth', key: 'growth' }
  ];

  return <Table columns={columns} dataSource={data} />;
};
```

### **AFTER: Material UI DataGrid**
```javascript
import { DataGrid } from '@mui/x-data-grid';
import { Box } from '@mui/material';

const SalesTable = ({ data }) => {
  const columns = [
    { field: 'country', headerName: 'Country', flex: 1 },
    { field: 'sales', headerName: 'Sales', flex: 1, type: 'number' },
    { field: 'growth', headerName: 'Growth', flex: 1, type: 'number' }
  ];

  return (
    <Box sx={{ height: 600, width: '100%' }}>
      <DataGrid 
        rows={data} 
        columns={columns}
        pageSize={10}
        checkboxSelection
        disableSelectionOnClick
        sx={{
          '& .MuiDataGrid-cell:hover': {
            color: 'primary.main'
          }
        }}
      />
    </Box>
  );
};
```

---

## 📊 Card/KPI Component Conversion

### **BEFORE: Ant Design Card**
```javascript
import { Card, Statistic } from 'antd';
import { ArrowUpOutlined } from '@ant-design/icons';

const KPICard = () => (
  <Card>
    <Statistic
      title="Total Sales"
      value={112893}
      precision={2}
      valueStyle={{ color: '#3f8600' }}
      prefix={<ArrowUpOutlined />}
      suffix="%"
    />
  </Card>
);
```

### **AFTER: Material UI Card**
```javascript
import { Card, CardContent, Typography, Box } from '@mui/material';
import { TrendingUp } from '@mui/icons-material';

const KPICard = () => (
  <Card elevation={2}>
    <CardContent>
      <Box display="flex" justifyContent="space-between" alignItems="flex-start">
        <Box>
          <Typography variant="body2" color="text.secondary" gutterBottom>
            Total Sales
          </Typography>
          <Typography variant="h4" fontWeight={600}>
            112,893
          </Typography>
          <Box display="flex" alignItems="center" mt={1}>
            <TrendingUp fontSize="small" color="success" />
            <Typography variant="body2" color="success.main" ml={0.5}>
              12.5%
            </Typography>
          </Box>
        </Box>
        <Box
          sx={{
            width: 48,
            height: 48,
            borderRadius: 2,
            backgroundColor: 'success.lighter',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center'
          }}
        >
          <TrendingUp color="success" />
        </Box>
      </Box>
    </CardContent>
  </Card>
);
```

---

## 📝 Form Conversion

### **BEFORE: Ant Design Form**
```javascript
import { Form, Input, Button } from 'antd';

const LoginForm = () => {
  const [form] = Form.useForm();

  const onFinish = (values) => {
    console.log(values);
  };

  return (
    <Form form={form} onFinish={onFinish} layout="vertical">
      <Form.Item 
        label="Email" 
        name="email"
        rules={[{ required: true, type: 'email' }]}
      >
        <Input />
      </Form.Item>
      <Form.Item 
        label="Password" 
        name="password"
        rules={[{ required: true }]}
      >
        <Input.Password />
      </Form.Item>
      <Form.Item>
        <Button type="primary" htmlType="submit" block>
          Sign In
        </Button>
      </Form.Item>
    </Form>
  );
};
```

### **AFTER: Material UI Form (with react-hook-form)**
```javascript
import { TextField, Button, Box } from '@mui/material';
import { useForm } from 'react-hook-form';

const LoginForm = () => {
  const { register, handleSubmit, formState: { errors } } = useForm();

  const onSubmit = (data) => {
    console.log(data);
  };

  return (
    <Box component="form" onSubmit={handleSubmit(onSubmit)}>
      <TextField
        fullWidth
        label="Email"
        type="email"
        margin="normal"
        {...register('email', { 
          required: 'Email is required',
          pattern: {
            value: /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i,
            message: 'Invalid email address'
          }
        })}
        error={!!errors.email}
        helperText={errors.email?.message}
      />
      <TextField
        fullWidth
        label="Password"
        type="password"
        margin="normal"
        {...register('password', { required: 'Password is required' })}
        error={!!errors.password}
        helperText={errors.password?.message}
      />
      <Button 
        fullWidth 
        variant="contained" 
        size="large" 
        type="submit"
        sx={{ mt: 2 }}
      >
        Sign In
      </Button>
    </Box>
  );
};
```

---

## 🎨 Button Conversion

### **BEFORE: Ant Design Buttons**
```javascript
import { Button, Space } from 'antd';
import { DownloadOutlined } from '@ant-design/icons';

<Space>
  <Button type="primary">Primary</Button>
  <Button type="default">Default</Button>
  <Button type="dashed">Dashed</Button>
  <Button type="text">Text</Button>
  <Button type="link">Link</Button>
  <Button type="primary" icon={<DownloadOutlined />}>
    Download
  </Button>
</Space>
```

### **AFTER: Material UI Buttons**
```javascript
import { Button, Stack } from '@mui/material';
import { Download } from '@mui/icons-material';

<Stack direction="row" spacing={2}>
  <Button variant="contained">Primary</Button>
  <Button variant="outlined">Default</Button>
  <Button variant="outlined" sx={{ borderStyle: 'dashed' }}>Dashed</Button>
  <Button variant="text">Text</Button>
  <Button variant="text" href="#">Link</Button>
  <Button variant="contained" startIcon={<Download />}>
    Download
  </Button>
</Stack>
```

---

## 🔔 Notification/Alert Conversion

### **BEFORE: Ant Design Message**
```javascript
import { message, notification } from 'antd';

// Simple message
message.success('Data saved successfully!');
message.error('Something went wrong!');
message.warning('Please check your input');

// Notification
notification.open({
  message: 'Update Available',
  description: 'A new version of the app is available.',
  placement: 'topRight'
});
```

### **AFTER: Material UI Snackbar**
```javascript
import { Snackbar, Alert } from '@mui/material';
import { useState } from 'react';

const MyComponent = () => {
  const [open, setOpen] = useState(false);
  const [severity, setSeverity] = useState('success');
  const [message, setMessage] = useState('');

  const showMessage = (msg, type = 'success') => {
    setMessage(msg);
    setSeverity(type);
    setOpen(true);
  };

  return (
    <>
      <Button onClick={() => showMessage('Data saved!', 'success')}>
        Save
      </Button>

      <Snackbar
        open={open}
        autoHideDuration={6000}
        onClose={() => setOpen(false)}
        anchorOrigin={{ vertical: 'top', horizontal: 'right' }}
      >
        <Alert 
          onClose={() => setOpen(false)} 
          severity={severity}
          variant="filled"
        >
          {message}
        </Alert>
      </Snackbar>
    </>
  );
};
```

**Or use a custom hook:**
```javascript
// hooks/useNotification.js
import { useState } from 'react';

export const useNotification = () => {
  const [notification, setNotification] = useState({
    open: false,
    message: '',
    severity: 'info'
  });

  const showNotification = (message, severity = 'info') => {
    setNotification({ open: true, message, severity });
  };

  const hideNotification = () => {
    setNotification(prev => ({ ...prev, open: false }));
  };

  return { notification, showNotification, hideNotification };
};
```

---

## 🎭 Modal/Dialog Conversion

### **BEFORE: Ant Design Modal**
```javascript
import { Modal, Button } from 'antd';
import { useState } from 'react';

const MyModal = () => {
  const [visible, setVisible] = useState(false);

  return (
    <>
      <Button onClick={() => setVisible(true)}>Open Modal</Button>
      <Modal
        title="Confirm Action"
        visible={visible}
        onOk={() => setVisible(false)}
        onCancel={() => setVisible(false)}
        okText="Confirm"
        cancelText="Cancel"
      >
        <p>Are you sure you want to proceed?</p>
      </Modal>
    </>
  );
};
```

### **AFTER: Material UI Dialog**
```javascript
import { 
  Dialog, 
  DialogTitle, 
  DialogContent, 
  DialogActions, 
  DialogContentText,
  Button 
} from '@mui/material';
import { useState } from 'react';

const MyDialog = () => {
  const [open, setOpen] = useState(false);

  return (
    <>
      <Button variant="contained" onClick={() => setOpen(true)}>
        Open Dialog
      </Button>
      <Dialog
        open={open}
        onClose={() => setOpen(false)}
        maxWidth="sm"
        fullWidth
      >
        <DialogTitle>Confirm Action</DialogTitle>
        <DialogContent>
          <DialogContentText>
            Are you sure you want to proceed?
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setOpen(false)}>Cancel</Button>
          <Button onClick={() => setOpen(false)} variant="contained">
            Confirm
          </Button>
        </DialogActions>
      </Dialog>
    </>
  );
};
```

---

## 📑 Tabs Conversion

### **BEFORE: Ant Design Tabs**
```javascript
import { Tabs } from 'antd';

const { TabPane } = Tabs;

<Tabs defaultActiveKey="1">
  <TabPane tab="Tab 1" key="1">
    Content of Tab 1
  </TabPane>
  <TabPane tab="Tab 2" key="2">
    Content of Tab 2
  </TabPane>
  <TabPane tab="Tab 3" key="3">
    Content of Tab 3
  </TabPane>
</Tabs>
```

### **AFTER: Material UI Tabs**
```javascript
import { Tabs, Tab, Box } from '@mui/material';
import { useState } from 'react';

const TabPanel = ({ children, value, index }) => (
  <div hidden={value !== index}>
    {value === index && <Box sx={{ p: 3 }}>{children}</Box>}
  </div>
);

const MyTabs = () => {
  const [value, setValue] = useState(0);

  return (
    <Box>
      <Tabs 
        value={value} 
        onChange={(e, newValue) => setValue(newValue)}
        sx={{ borderBottom: 1, borderColor: 'divider' }}
      >
        <Tab label="Tab 1" />
        <Tab label="Tab 2" />
        <Tab label="Tab 3" />
      </Tabs>
      <TabPanel value={value} index={0}>
        Content of Tab 1
      </TabPanel>
      <TabPanel value={value} index={1}>
        Content of Tab 2
      </TabPanel>
      <TabPanel value={value} index={2}>
        Content of Tab 3
      </TabPanel>
    </Box>
  );
};
```

---

## 🎨 Select/Dropdown Conversion

### **BEFORE: Ant Design Select**
```javascript
import { Select } from 'antd';

const { Option } = Select;

<Select 
  placeholder="Select country"
  style={{ width: 200 }}
  onChange={(value) => console.log(value)}
>
  <Option value="usa">United States</Option>
  <Option value="uk">United Kingdom</Option>
  <Option value="jp">Japan</Option>
</Select>
```

### **AFTER: Material UI Select**
```javascript
import { FormControl, InputLabel, Select, MenuItem } from '@mui/material';
import { useState } from 'react';

const MySelect = () => {
  const [value, setValue] = useState('');

  return (
    <FormControl sx={{ width: 200 }}>
      <InputLabel>Select Country</InputLabel>
      <Select
        value={value}
        label="Select Country"
        onChange={(e) => setValue(e.target.value)}
      >
        <MenuItem value="usa">United States</MenuItem>
        <MenuItem value="uk">United Kingdom</MenuItem>
        <MenuItem value="jp">Japan</MenuItem>
      </Select>
    </FormControl>
  );
};
```

---

## 📅 DatePicker Conversion

### **BEFORE: Ant Design DatePicker**
```javascript
import { DatePicker } from 'antd';
import dayjs from 'dayjs';

<DatePicker 
  format="YYYY-MM-DD"
  onChange={(date, dateString) => console.log(dateString)}
/>
```

### **AFTER: Material UI DatePicker**
```javascript
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import { DatePicker } from '@mui/x-date-pickers/DatePicker';
import { useState } from 'react';
import dayjs from 'dayjs';

// Install first: npm install @mui/x-date-pickers dayjs

const MyDatePicker = () => {
  const [value, setValue] = useState(dayjs());

  return (
    <LocalizationProvider dateAdapter={AdapterDayjs}>
      <DatePicker
        label="Select Date"
        value={value}
        onChange={(newValue) => setValue(newValue)}
      />
    </LocalizationProvider>
  );
};
```

---

## 📦 Drawer Conversion

### **BEFORE: Ant Design Drawer**
```javascript
import { Drawer, Button } from 'antd';
import { useState } from 'react';

const MyDrawer = () => {
  const [visible, setVisible] = useState(false);

  return (
    <>
      <Button onClick={() => setVisible(true)}>Open</Button>
      <Drawer
        title="Drawer Title"
        placement="right"
        onClose={() => setVisible(false)}
        visible={visible}
        width={400}
      >
        <p>Drawer content...</p>
      </Drawer>
    </>
  );
};
```

### **AFTER: Material UI Drawer**
```javascript
import { Drawer, Button, Box, Typography, IconButton } from '@mui/material';
import { Close } from '@mui/icons-material';
import { useState } from 'react';

const MyDrawer = () => {
  const [open, setOpen] = useState(false);

  return (
    <>
      <Button variant="contained" onClick={() => setOpen(true)}>
        Open
      </Button>
      <Drawer
        anchor="right"
        open={open}
        onClose={() => setOpen(false)}
        sx={{ '& .MuiDrawer-paper': { width: 400 } }}
      >
        <Box sx={{ p: 3 }}>
          <Box display="flex" justifyContent="space-between" alignItems="center" mb={2}>
            <Typography variant="h6">Drawer Title</Typography>
            <IconButton onClick={() => setOpen(false)}>
              <Close />
            </IconButton>
          </Box>
          <Typography>Drawer content...</Typography>
        </Box>
      </Drawer>
    </>
  );
};
```

---

## 🔄 Loading/Spinner Conversion

### **BEFORE: Ant Design Spin**
```javascript
import { Spin } from 'antd';

<Spin tip="Loading...">
  <div style={{ minHeight: 200 }}>
    Content
  </div>
</Spin>
```

### **AFTER: Material UI CircularProgress**
```javascript
import { CircularProgress, Box, Typography } from '@mui/material';

const Loading = ({ loading, children }) => {
  if (loading) {
    return (
      <Box 
        display="flex" 
        flexDirection="column"
        alignItems="center" 
        justifyContent="center" 
        minHeight={200}
      >
        <CircularProgress />
        <Typography variant="body2" color="text.secondary" mt={2}>
          Loading...
        </Typography>
      </Box>
    );
  }
  return children;
};
```

---

## 🎯 Grid/Layout Conversion

### **BEFORE: Ant Design Grid**
```javascript
import { Row, Col } from 'antd';

<Row gutter={16}>
  <Col xs={24} sm={12} md={8} lg={6}>
    <div>Column 1</div>
  </Col>
  <Col xs={24} sm={12} md={8} lg={6}>
    <div>Column 2</div>
  </Col>
  <Col xs={24} sm={12} md={8} lg={6}>
    <div>Column 3</div>
  </Col>
  <Col xs={24} sm={12} md={8} lg={6}>
    <div>Column 4</div>
  </Col>
</Row>
```

### **AFTER: Material UI Grid**
```javascript
import { Grid } from '@mui/material';

<Grid container spacing={2}>
  <Grid item xs={12} sm={6} md={4} lg={3}>
    <div>Column 1</div>
  </Grid>
  <Grid item xs={12} sm={6} md={4} lg={3}>
    <div>Column 2</div>
  </Grid>
  <Grid item xs={12} sm={6} md={4} lg={3}>
    <div>Column 3</div>
  </Grid>
  <Grid item xs={12} sm={6} md={4} lg={3}>
    <div>Column 4</div>
  </Grid>
</Grid>
```

---

## 📚 Icon Conversion

### **Icon Library Mapping**
```javascript
// Ant Design Icons → Material UI Icons

import { 
  UserOutlined,      // → PersonOutline
  HomeOutlined,      // → HomeOutlined
  SettingOutlined,   // → SettingsOutlined
  DeleteOutlined,    // → DeleteOutline
  EditOutlined,      // → EditOutlined
  PlusOutlined,      // → AddOutlined
  SearchOutlined,    // → SearchOutlined
  DownloadOutlined,  // → DownloadOutlined
  UploadOutlined,    // → UploadOutlined
  CloseOutlined,     // → CloseOutlined
  CheckOutlined,     // → CheckOutlined
  WarningOutlined,   // → WarningOutlined
  InfoCircleOutlined // → InfoOutlined
} from '@ant-design/icons';

// Becomes:

import {
  PersonOutline,
  HomeOutlined,
  SettingsOutlined,
  DeleteOutline,
  EditOutlined,
  AddOutlined,
  SearchOutlined,
  DownloadOutlined,
  UploadOutlined,
  CloseOutlined,
  CheckOutlined,
  WarningOutlined,
  InfoOutlined
} from '@mui/icons-material';
```

---

## 🎨 Styling Comparison

### **Ant Design Inline Styles**
```javascript
<div style={{ 
  backgroundColor: '#1890ff', 
  padding: '20px',
  borderRadius: '4px'
}}>
  Content
</div>
```

### **Material UI sx Prop (Recommended)**
```javascript
<Box sx={{ 
  backgroundColor: 'primary.main',
  p: 2.5,  // 20px (8px * 2.5)
  borderRadius: 1  // 8px default
}}>
  Content
</Box>
```

### **MUI Spacing Scale**
```javascript
// Material UI uses 8px base unit
p: 1    // padding: 8px
p: 2    // padding: 16px
p: 3    // padding: 24px
m: 2    // margin: 16px
mx: 2   // margin-left & margin-right: 16px
my: 1   // margin-top & margin-bottom: 8px
```

---

## 🚀 Performance Tips

### **1. Use MUI System Props**
```javascript
// ✅ GOOD (optimized)
<Box sx={{ display: 'flex', gap: 2, p: 3 }}>

// ❌ BAD (creates new object each render)
<Box style={{ display: 'flex', gap: '16px', padding: '24px' }}>
```

### **2. Lazy Load Icons**
```javascript
// ✅ GOOD (tree-shakeable)
import DeleteIcon from '@mui/icons-material/Delete';

// ❌ BAD (imports all icons)
import { Delete } from '@mui/icons-material';
```

### **3. Use Component Composition**
```javascript
// Create reusable styled components
const StyledCard = styled(Card)(({ theme }) => ({
  borderRadius: theme.spacing(2),
  boxShadow: theme.shadows[2],
  '&:hover': {
    boxShadow: theme.shadows[4]
  }
}));
```

---

## 📝 TypeScript Props Example

### **BEFORE: PropTypes**
```javascript
import PropTypes from 'prop-types';

const MyComponent = ({ title, count, onAction }) => {
  return <div>{title}: {count}</div>;
};

MyComponent.propTypes = {
  title: PropTypes.string.isRequired,
  count: PropTypes.number,
  onAction: PropTypes.func
};
```

### **AFTER: TypeScript**
```typescript
interface MyComponentProps {
  title: string;
  count?: number;
  onAction?: () => void;
}

const MyComponent: React.FC<MyComponentProps> = ({ 
  title, 
  count = 0, 
  onAction 
}) => {
  return <div>{title}: {count}</div>;
};
```

---

## ✅ Migration Checklist Per Component

For each component you migrate:

- [ ] Replace Ant Design imports with MUI
- [ ] Update inline styles to `sx` prop
- [ ] Convert class names to MUI system props
- [ ] Update icons from `@ant-design/icons` to `@mui/icons-material`
- [ ] Replace `gutter`/spacing with MUI spacing scale
- [ ] Test responsive behavior
- [ ] Add TypeScript types (optional but recommended)
- [ ] Test dark mode compatibility
- [ ] Verify accessibility (keyboard navigation, ARIA)

---

## 🎯 Cursor Commands for Fast Migration

**In Cursor IDE, use these prompts:**

1. **Select component code + Cmd/Ctrl + K**
   ```
   "Convert this Ant Design component to Material UI keeping all functionality"
   ```

2. **For entire files (Cmd/Ctrl + L in chat)**
   ```
   "Migrate this file from Ant Design to Material UI, use TypeScript, 
   follow Crema design patterns with proper spacing and theme integration"
   ```

3. **For styling fixes**
   ```
   "Convert these inline styles to MUI sx prop with theme values"
   ```

4. **For forms**
   ```
   "Convert this Ant Design form to Material UI with react-hook-form validation"
   ```

---

**This quick reference should help you convert components efficiently in Cursor!** 🚀
