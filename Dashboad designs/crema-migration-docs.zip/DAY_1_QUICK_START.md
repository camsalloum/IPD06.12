# 🚀 Day 1 Quick Start Guide

**Get started with your Crema-style migration in Cursor IDE today!**

---

## ⚡ 30-Minute Setup (Do This First)

### **Step 1: Install Dependencies (5 minutes)**

```bash
# Navigate to your project
cd IPD26.10

# Install Material UI Core (required)
npm install @mui/material@latest @emotion/react @emotion/styled

# Install Material UI Icons
npm install @mui/icons-material@latest

# Install Material UI Extended Components
npm install @mui/x-data-grid @mui/x-date-pickers

# Install Additional Utilities
npm install dayjs react-hook-form

# Install TypeScript types (optional but recommended)
npm install --save-dev @types/react @types/react-dom @types/node
```

### **Step 2: Create Theme Foundation (10 minutes)**

**Create**: `src/theme/palette.js`
```javascript
export const lightPalette = {
  mode: 'light',
  primary: {
    main: '#0A8FDC',
    light: '#42A5F5',
    dark: '#0277BD',
    contrastText: '#fff'
  },
  secondary: {
    main: '#F04F47',
    light: '#FF6F61',
    dark: '#C62828',
    contrastText: '#fff'
  },
  success: {
    main: '#52C41A',
    light: '#73D13D',
    dark: '#389E0D'
  },
  warning: {
    main: '#FAAD14',
    light: '#FFC53D',
    dark: '#D48806'
  },
  error: {
    main: '#F44336',
    light: '#E57373',
    dark: '#D32F2F'
  },
  info: {
    main: '#1890FF',
    light: '#40A9FF',
    dark: '#096DD9'
  },
  background: {
    default: '#F4F7FE',
    paper: '#FFFFFF'
  },
  text: {
    primary: '#313541',
    secondary: '#6F7C87',
    disabled: '#A8AAB3'
  },
  divider: '#E8EAED'
};

export const darkPalette = {
  mode: 'dark',
  primary: {
    main: '#0A8FDC',
    light: '#42A5F5',
    dark: '#0277BD',
    contrastText: '#fff'
  },
  secondary: {
    main: '#F04F47',
    light: '#FF6F61',
    dark: '#C62828',
    contrastText: '#fff'
  },
  success: {
    main: '#52C41A',
    light: '#73D13D',
    dark: '#389E0D'
  },
  warning: {
    main: '#FAAD14',
    light: '#FFC53D',
    dark: '#D48806'
  },
  error: {
    main: '#F44336',
    light: '#E57373',
    dark: '#D32F2F'
  },
  background: {
    default: '#1A1D2E',
    paper: '#262939'
  },
  text: {
    primary: '#FFFFFF',
    secondary: '#A8AAB3',
    disabled: '#6F7C87'
  },
  divider: '#3A3D4F'
};
```

**Create**: `src/theme/index.js`
```javascript
import { createTheme } from '@mui/material/styles';
import { lightPalette, darkPalette } from './palette';

export const createAppTheme = (mode = 'light') => {
  const palette = mode === 'dark' ? darkPalette : lightPalette;

  return createTheme({
    palette,
    typography: {
      fontFamily: [
        'Inter',
        'Roboto',
        '-apple-system',
        'BlinkMacSystemFont',
        '"Segoe UI"',
        'Arial',
        'sans-serif'
      ].join(','),
      h1: {
        fontSize: '2.5rem',
        fontWeight: 700,
        lineHeight: 1.2
      },
      h2: {
        fontSize: '2rem',
        fontWeight: 700,
        lineHeight: 1.3
      },
      h3: {
        fontSize: '1.75rem',
        fontWeight: 600,
        lineHeight: 1.3
      },
      h4: {
        fontSize: '1.5rem',
        fontWeight: 600,
        lineHeight: 1.4
      },
      h5: {
        fontSize: '1.25rem',
        fontWeight: 600,
        lineHeight: 1.4
      },
      h6: {
        fontSize: '1rem',
        fontWeight: 600,
        lineHeight: 1.5
      },
      subtitle1: {
        fontSize: '1rem',
        fontWeight: 500,
        lineHeight: 1.75
      },
      subtitle2: {
        fontSize: '0.875rem',
        fontWeight: 500,
        lineHeight: 1.57
      },
      body1: {
        fontSize: '1rem',
        lineHeight: 1.5
      },
      body2: {
        fontSize: '0.875rem',
        lineHeight: 1.43
      },
      button: {
        fontSize: '0.875rem',
        fontWeight: 500,
        textTransform: 'none'
      },
      caption: {
        fontSize: '0.75rem',
        lineHeight: 1.66
      }
    },
    shape: {
      borderRadius: 8
    },
    spacing: 8,
    shadows: [
      'none',
      '0px 2px 4px rgba(0, 0, 0, 0.05)',
      '0px 4px 8px rgba(0, 0, 0, 0.08)',
      '0px 8px 16px rgba(0, 0, 0, 0.1)',
      '0px 12px 24px rgba(0, 0, 0, 0.12)',
      '0px 16px 32px rgba(0, 0, 0, 0.14)',
      '0px 20px 40px rgba(0, 0, 0, 0.16)',
      '0px 24px 48px rgba(0, 0, 0, 0.18)',
      '0px 28px 56px rgba(0, 0, 0, 0.2)',
      ...Array(16).fill('none')
    ],
    components: {
      MuiButton: {
        styleOverrides: {
          root: {
            borderRadius: 8,
            padding: '8px 16px',
            fontWeight: 500,
            boxShadow: 'none',
            '&:hover': {
              boxShadow: '0px 4px 8px rgba(0, 0, 0, 0.1)'
            }
          },
          sizeLarge: {
            padding: '12px 24px',
            fontSize: '1rem'
          },
          sizeSmall: {
            padding: '6px 12px',
            fontSize: '0.813rem'
          }
        }
      },
      MuiCard: {
        styleOverrides: {
          root: {
            borderRadius: 12,
            boxShadow: '0px 4px 8px rgba(0, 0, 0, 0.08)',
            '&:hover': {
              boxShadow: '0px 8px 16px rgba(0, 0, 0, 0.12)'
            }
          }
        }
      },
      MuiPaper: {
        styleOverrides: {
          root: {
            borderRadius: 8
          },
          elevation1: {
            boxShadow: '0px 2px 4px rgba(0, 0, 0, 0.05)'
          },
          elevation2: {
            boxShadow: '0px 4px 8px rgba(0, 0, 0, 0.08)'
          }
        }
      },
      MuiTextField: {
        styleOverrides: {
          root: {
            '& .MuiOutlinedInput-root': {
              borderRadius: 8
            }
          }
        }
      },
      MuiChip: {
        styleOverrides: {
          root: {
            borderRadius: 6,
            fontWeight: 500
          }
        }
      },
      MuiAppBar: {
        styleOverrides: {
          root: {
            boxShadow: '0px 1px 3px rgba(0, 0, 0, 0.05)'
          }
        }
      }
    }
  });
};

export default createAppTheme;
```

### **Step 3: Create Theme Context (5 minutes)**

**Create**: `src/contexts/ThemeContext.jsx`
```javascript
import React, { createContext, useState, useMemo } from 'react';
import { ThemeProvider as MuiThemeProvider } from '@mui/material/styles';
import { ConfigProvider } from 'antd';
import CssBaseline from '@mui/material/CssBaseline';
import { createAppTheme } from '../theme';

export const ThemeContext = createContext({
  mode: 'light',
  toggleTheme: () => {},
  setMode: () => {}
});

export const AppThemeProvider = ({ children }) => {
  const [mode, setMode] = useState('light');

  const theme = useMemo(() => createAppTheme(mode), [mode]);

  const toggleTheme = () => {
    setMode((prevMode) => (prevMode === 'light' ? 'dark' : 'light'));
  };

  const value = {
    mode,
    setMode,
    toggleTheme
  };

  return (
    <ThemeContext.Provider value={value}>
      <MuiThemeProvider theme={theme}>
        <ConfigProvider
          theme={{
            token: {
              colorPrimary: theme.palette.primary.main,
              borderRadius: 8,
              colorBgContainer: theme.palette.background.paper,
              colorText: theme.palette.text.primary
            }
          }}
        >
          <CssBaseline />
          {children}
        </ConfigProvider>
      </MuiThemeProvider>
    </ThemeContext.Provider>
  );
};

export const useThemeContext = () => {
  const context = React.useContext(ThemeContext);
  if (!context) {
    throw new Error('useThemeContext must be used within AppThemeProvider');
  }
  return context;
};
```

### **Step 4: Update App.js (5 minutes)**

**Edit**: `src/App.js`
```javascript
import React from 'react';
import { BrowserRouter as Router } from 'react-router-dom';
import { AppThemeProvider } from './contexts/ThemeContext';
// Keep your existing context providers
import { ExcelDataProvider } from './contexts/ExcelDataContext';
import { FilterProvider } from './contexts/FilterContext';
// ... other existing providers

function App() {
  return (
    <AppThemeProvider>  {/* Add this wrapper */}
      <Router>
        <ExcelDataProvider>
          <FilterProvider>
            {/* Your existing app structure */}
            <YourExistingAppContent />
          </FilterProvider>
        </ExcelDataProvider>
      </Router>
    </AppThemeProvider>
  );
}

export default App;
```

### **Step 5: Add Google Fonts (2 minutes)**

**Edit**: `public/index.html`
```html
<head>
  <!-- ... existing head content ... -->
  
  <!-- Add Inter Font -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
</head>
```

### **Step 6: Test Setup (3 minutes)**

**Create**: `src/components/TestMUI.jsx` (temporary test component)
```javascript
import React from 'react';
import { Box, Button, Card, CardContent, Typography } from '@mui/material';
import { useThemeContext } from '../contexts/ThemeContext';

const TestMUI = () => {
  const { mode, toggleTheme } = useThemeContext();

  return (
    <Box sx={{ p: 4 }}>
      <Typography variant="h4" gutterBottom>
        Material UI Setup Test
      </Typography>
      
      <Card sx={{ maxWidth: 400, mt: 2 }}>
        <CardContent>
          <Typography variant="h6">Current Theme: {mode}</Typography>
          <Button 
            variant="contained" 
            onClick={toggleTheme}
            sx={{ mt: 2 }}
          >
            Toggle Theme
          </Button>
        </CardContent>
      </Card>
    </Box>
  );
};

export default TestMUI;
```

Add this to your routes to test: `<Route path="/test-mui" element={<TestMUI />} />`

---

## 📋 Your First Component Migration (1 hour)

Let's migrate your Dashboard/Home page as the first component!

### **Current File**: `src/components/dashboard/Dashboard.js` (or wherever your home is)

**Use Cursor to migrate it:**

1. **Open the file in Cursor**
2. **Select all the code (Cmd/Ctrl + A)**
3. **Open Cursor AI (Cmd/Ctrl + K)**
4. **Enter this prompt:**

```
Convert this React component from Ant Design to Material UI following these requirements:

1. Replace all Ant Design components with Material UI equivalents
2. Use MUI Grid for layout (spacing={3})
3. Create styled KPI cards with icons
4. Use sx prop for all styling (no inline styles)
5. Keep all existing functionality and data flow
6. Use theme colors (primary.main, success.main, etc.)
7. Add proper TypeScript types if missing
8. Make it responsive (xs, sm, md, lg breakpoints)
9. Follow Crema design pattern: clean cards with subtle shadows
10. Keep existing chart integrations (ECharts)

Design style:
- Modern, clean Crema-style cards
- Rounded corners (borderRadius: 2)
- Subtle shadows (elevation={2})
- Proper spacing between elements
- Hover effects on cards
```

### **Example Output Structure:**

```javascript
import React from 'react';
import { 
  Box, 
  Grid, 
  Card, 
  CardContent, 
  Typography,
  useTheme 
} from '@mui/material';
import { 
  TrendingUp, 
  AttachMoney, 
  People, 
  ShoppingCart 
} from '@mui/icons-material';

// Your existing imports
import { useExcelData } from '../../contexts/ExcelDataContext';
import MyEChartsComponent from '../charts/MyEChartsComponent';

const Dashboard = () => {
  const theme = useTheme();
  const { data } = useExcelData(); // Keep your existing hooks

  // Your existing logic...

  return (
    <Box>
      {/* Page Title */}
      <Typography variant="h4" fontWeight={600} mb={3}>
        Dashboard Overview
      </Typography>

      {/* KPI Cards */}
      <Grid container spacing={3}>
        <Grid item xs={12} sm={6} md={3}>
          <Card elevation={2}>
            <CardContent>
              <Box display="flex" justifyContent="space-between" alignItems="flex-start">
                <Box>
                  <Typography variant="body2" color="text.secondary">
                    Total Sales
                  </Typography>
                  <Typography variant="h4" fontWeight={600} mt={1}>
                    $2.4M
                  </Typography>
                  <Box display="flex" alignItems="center" mt={1}>
                    <TrendingUp fontSize="small" color="success" />
                    <Typography variant="body2" color="success.main" ml={0.5}>
                      +12.5%
                    </Typography>
                  </Box>
                </Box>
                <Box
                  sx={{
                    width: 48,
                    height: 48,
                    borderRadius: 2,
                    backgroundColor: 'primary.lighter',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center'
                  }}
                >
                  <AttachMoney color="primary" />
                </Box>
              </Box>
            </CardContent>
          </Card>
        </Grid>

        {/* Add 3 more similar KPI cards */}
      </Grid>

      {/* Charts Section */}
      <Grid container spacing={3} mt={1}>
        <Grid item xs={12} md={8}>
          <Card elevation={2}>
            <CardContent>
              <Typography variant="h6" mb={2}>
                Sales Trend
              </Typography>
              {/* Your existing ECharts component */}
              <MyEChartsComponent />
            </CardContent>
          </Card>
        </Grid>

        <Grid item xs={12} md={4}>
          <Card elevation={2}>
            <CardContent>
              <Typography variant="h6" mb={2}>
                Top Products
              </Typography>
              {/* Your existing list */}
            </CardContent>
          </Card>
        </Grid>
      </Grid>
    </Box>
  );
};

export default Dashboard;
```

---

## 🎨 Create Your First Reusable Component (30 minutes)

**Create**: `src/components/common/KPICard.jsx`

```javascript
import React from 'react';
import { Card, CardContent, Typography, Box } from '@mui/material';
import { TrendingUp, TrendingDown } from '@mui/icons-material';

const KPICard = ({ 
  title, 
  value, 
  change, 
  icon: Icon, 
  color = 'primary',
  loading = false 
}) => {
  const isPositive = change >= 0;

  return (
    <Card 
      elevation={2}
      sx={{
        height: '100%',
        transition: 'all 0.3s ease',
        '&:hover': {
          transform: 'translateY(-4px)',
          boxShadow: 4
        }
      }}
    >
      <CardContent>
        <Box display="flex" justifyContent="space-between" alignItems="flex-start">
          <Box flex={1}>
            <Typography 
              variant="body2" 
              color="text.secondary" 
              gutterBottom
              sx={{ mb: 1 }}
            >
              {title}
            </Typography>
            
            <Typography 
              variant="h4" 
              fontWeight={600}
              sx={{ mb: 1 }}
            >
              {value}
            </Typography>
            
            {change !== undefined && (
              <Box display="flex" alignItems="center">
                {isPositive ? (
                  <TrendingUp fontSize="small" color="success" />
                ) : (
                  <TrendingDown fontSize="small" color="error" />
                )}
                <Typography 
                  variant="body2" 
                  color={isPositive ? 'success.main' : 'error.main'}
                  fontWeight={500}
                  ml={0.5}
                >
                  {isPositive ? '+' : ''}{change}%
                </Typography>
                <Typography 
                  variant="caption" 
                  color="text.secondary"
                  ml={0.5}
                >
                  vs last period
                </Typography>
              </Box>
            )}
          </Box>

          {Icon && (
            <Box
              sx={{
                width: 56,
                height: 56,
                borderRadius: 2,
                backgroundColor: `${color}.lighter`,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                ml: 2
              }}
            >
              <Icon sx={{ color: `${color}.main`, fontSize: 28 }} />
            </Box>
          )}
        </Box>
      </CardContent>
    </Card>
  );
};

export default KPICard;
```

**Usage:**
```javascript
import KPICard from './components/common/KPICard';
import { AttachMoney, People, ShoppingCart, TrendingUp } from '@mui/icons-material';

<Grid container spacing={3}>
  <Grid item xs={12} sm={6} md={3}>
    <KPICard
      title="Total Sales"
      value="$2.4M"
      change={12.5}
      icon={AttachMoney}
      color="primary"
    />
  </Grid>
  <Grid item xs={12} sm={6} md={3}>
    <KPICard
      title="Active Users"
      value="1,254"
      change={-3.2}
      icon={People}
      color="success"
    />
  </Grid>
  {/* More KPI cards... */}
</Grid>
```

---

## 🎯 Quick Wins for Day 1

By end of day 1, you should have:

- [x] ✅ Material UI installed and configured
- [x] ✅ Theme system working (light/dark toggle)
- [x] ✅ First component migrated (Dashboard)
- [x] ✅ Reusable KPICard component created
- [x] ✅ Theme switching working
- [x] ✅ Basic understanding of MUI patterns

---

## 🔧 Troubleshooting

### **Issue: "Cannot find module @mui/material"**
```bash
# Make sure you installed it correctly
npm install @mui/material @emotion/react @emotion/styled
```

### **Issue: Theme not applying**
Check that `AppThemeProvider` wraps your entire app in `App.js`

### **Issue: Ant Design and MUI conflicts**
This is normal! You can run both side-by-side. Just import from the correct library:
```javascript
import { Button as AntButton } from 'antd';
import { Button as MuiButton } from '@mui/material';
```

### **Issue: Fonts not loading**
Clear browser cache and check that the Google Fonts link is in `public/index.html`

---

## 📚 Resources for Day 1

1. **MUI Documentation**: https://mui.com/material-ui/getting-started/
2. **MUI Component Gallery**: https://mui.com/material-ui/all-components/
3. **Crema Demo (for inspiration)**: https://cremawork.com/mui/
4. **MUI Icons Search**: https://mui.com/material-ui/material-icons/

---

## 🚀 Day 2 Preview

Tomorrow you'll:
1. Create the Sidebar component
2. Create the Header component
3. Build the Default Layout
4. Migrate 2-3 more pages

---

## 💡 Cursor Pro Tips for Day 1

### **1. Use Composer for Full Components**
```
Cmd/Ctrl + I (Opens Composer)

"Create a Material UI KPI card component following Crema design 
with props for title, value, trend percentage, and icon. Include 
hover effects and proper TypeScript types."
```

### **2. Use Inline Edit for Quick Changes**
```
Select code → Cmd/Ctrl + K

"Convert this to use MUI sx prop instead of inline styles"
```

### **3. Ask for Explanations**
```
Select unfamiliar code → Cmd/Ctrl + L

"Explain how this MUI theme configuration works"
```

### **4. Generate Multiple Variations**
```
In Chat (Cmd/Ctrl + L):

"Show me 3 different KPI card designs using Material UI"
```

---

## ✅ Day 1 Completion Checklist

At the end of Day 1, verify:

- [ ] ✅ MUI packages installed (check package.json)
- [ ] ✅ Theme files created (src/theme/)
- [ ] ✅ ThemeContext created and working
- [ ] ✅ App.js wrapped with AppThemeProvider
- [ ] ✅ Can toggle dark/light theme
- [ ] ✅ First page migrated to MUI
- [ ] ✅ KPICard component created
- [ ] ✅ Inter font loading
- [ ] ✅ No console errors
- [ ] ✅ Committed changes to Git

**Commit message**: `feat: Add Material UI theme system and migrate Dashboard`

---

**Congratulations! 🎉 You've completed Day 1 setup. Tomorrow we'll build the layout system!**

---

## 🎨 Preview of What You're Building

```
┌──────────────────────────────────────────────────────┐
│  IPD Dashboard                      🔔 👤            │  ← Header
├──────────┬───────────────────────────────────────────┤
│          │  Dashboard Overview                       │
│  📊 Dash │                                            │
│  📈 Sales│  ┌──────┐ ┌──────┐ ┌──────┐ ┌──────┐     │
│    • By  │  │ $2.4M│ │ 1.2K │ │ $156K│ │  89% │     │  ← KPI Cards
│      Cou.│  │Sales │ │Orders│ │Rev.  │ │Sat.  │     │
│    • By  │  └──────┘ └──────┘ └──────┘ └──────┘     │
│      Rep │                                            │
│  📊 Chart│  ┌────────────────┐ ┌──────────┐         │
│  🗺️ Maps │  │                │ │          │         │
│  📋 Data │  │  Sales Chart   │ │ Top Prod │         │  ← Charts
│  ⚙️ Sett.│  │                │ │          │         │
│          │  └────────────────┘ └──────────┘         │
└──────────┴───────────────────────────────────────────┘
   Sidebar          Main Content Area
```

Ready to transform your dashboard! 🚀
