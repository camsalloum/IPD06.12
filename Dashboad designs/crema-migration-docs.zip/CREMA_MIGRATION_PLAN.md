# 🎨 IPD26.10 → Crema-Style Dashboard Migration Plan

**Project**: Transform IPD26.10 Sales Analytics Dashboard to Crema-style UI
**Current Stack**: React 19 + Ant Design 5 + CRA + Context API + ECharts
**Target Style**: Crema React Admin Template Design System
**Implementation Tool**: Cursor IDE

---

## 📊 Current State Analysis

### ✅ What You Already Have (Compatible with Crema)
- ✅ React 19.1.0 (Crema supports React 19)
- ✅ Ant Design 5.25.1 (Crema supports ANTD5)
- ✅ Modern hooks-based components
- ✅ Context API for state management
- ✅ React Router DOM 7.6.3
- ✅ ECharts for data visualization
- ✅ Express + PostgreSQL backend

### ⚠️ What Needs to Be Added/Changed
- ❌ No Material UI (Crema's primary design system)
- ❌ No theme switching (light/dark/semi-dark modes)
- ❌ No configurable layouts (sidebar, header, drawer variations)
- ❌ TypeScript not configured (exists but not used)
- ❌ No centralized theming system
- ❌ Basic layout structure (needs 11+ layout variations)
- ❌ No RTL support
- ❌ Missing modern admin features (auth pages, error pages, etc.)

---

## 🎯 Migration Strategy: 3 Approaches

### **Option A: Hybrid Approach (RECOMMENDED)** ⭐
**Keep CRA + Add Crema Design System**
- ✅ Lower risk, gradual migration
- ✅ Keep existing backend integration
- ✅ Add Crema UI patterns incrementally
- ⏱️ Timeline: 6-8 weeks

### **Option B: Full Crema Integration**
**Purchase & Customize Crema Template**
- ✅ Get all pre-built components
- ✅ Professional design out-of-the-box
- ❌ Need to migrate all existing components
- ⏱️ Timeline: 8-12 weeks
- 💰 Cost: $29 (Regular License)

### **Option C: Next.js Migration**
**Migrate to Next.js + Crema Design**
- ✅ Better performance (SSR/SSG)
- ✅ Modern architecture
- ❌ Requires backend API changes
- ❌ Complete rewrite
- ⏱️ Timeline: 12-16 weeks

---

## 🚀 RECOMMENDED PLAN: Option A (Hybrid Approach)

---

## 📅 Phase-by-Phase Implementation Plan

### **PHASE 1: Foundation & Setup** (Week 1-2)

#### 1.1 Install Core Dependencies
```bash
# Material UI (Crema's primary UI library)
npm install @mui/material@7 @emotion/react @emotion/styled
npm install @mui/icons-material@7
npm install @mui/x-data-grid @mui/x-date-pickers

# Keep Ant Design (you already have v5)
# Keep existing: antd@5.25.1

# Theme & Styling
npm install @mui/system
npm install styled-components

# State Management (optional - you already use Context)
npm install @reduxjs/toolkit react-redux

# Charts (keep ECharts, optionally add Recharts)
npm install recharts

# TypeScript Configuration
npm install --save-dev @types/react @types/react-dom @types/node
```

#### 1.2 Configure TypeScript
Create `tsconfig.json`:
```json
{
  "compilerOptions": {
    "target": "ES2020",
    "lib": ["ES2020", "DOM", "DOM.Iterable"],
    "jsx": "react-jsx",
    "module": "ESNext",
    "moduleResolution": "node",
    "strict": true,
    "esModuleInterop": true,
    "skipLibCheck": true,
    "forceConsistentCasingInFileNames": true,
    "resolveJsonModule": true,
    "isolatedModules": true,
    "noEmit": true,
    "baseUrl": "src",
    "paths": {
      "@components/*": ["components/*"],
      "@contexts/*": ["contexts/*"],
      "@utils/*": ["utils/*"],
      "@services/*": ["services/*"]
    }
  },
  "include": ["src"],
  "exclude": ["node_modules"]
}
```

#### 1.3 Create Theme System
**Create**: `src/theme/index.js`

```javascript
import { createTheme } from '@mui/material/styles';

// Crema-style color palette
const lightPalette = {
  primary: { main: '#0A8FDC' },
  secondary: { main: '#F04F47' },
  success: { main: '#52C41A' },
  warning: { main: '#FAAD14' },
  error: { main: '#F44336' },
  background: {
    default: '#F4F7FE',
    paper: '#FFFFFF'
  },
  text: {
    primary: '#313541',
    secondary: '#6F7C87'
  }
};

const darkPalette = {
  primary: { main: '#0A8FDC' },
  secondary: { main: '#F04F47' },
  background: {
    default: '#1A1D2E',
    paper: '#262939'
  },
  text: {
    primary: '#FFFFFF',
    secondary: '#A8AAB3'
  }
};

export const createAppTheme = (mode = 'light') => {
  return createTheme({
    palette: {
      mode,
      ...(mode === 'light' ? lightPalette : darkPalette)
    },
    typography: {
      fontFamily: '"Inter", "Roboto", "Helvetica", "Arial", sans-serif',
      h1: { fontSize: '2.5rem', fontWeight: 600 },
      h2: { fontSize: '2rem', fontWeight: 600 },
      h3: { fontSize: '1.75rem', fontWeight: 600 },
      h4: { fontSize: '1.5rem', fontWeight: 500 },
      h5: { fontSize: '1.25rem', fontWeight: 500 },
      h6: { fontSize: '1rem', fontWeight: 500 }
    },
    shape: {
      borderRadius: 8
    },
    components: {
      MuiButton: {
        styleOverrides: {
          root: {
            textTransform: 'none',
            borderRadius: 8,
            fontWeight: 500
          }
        }
      },
      MuiCard: {
        styleOverrides: {
          root: {
            boxShadow: '0 2px 8px rgba(0,0,0,0.08)',
            borderRadius: 12
          }
        }
      }
    }
  });
};
```

#### 1.4 Create Theme Provider Context
**Create**: `src/contexts/ThemeContext.js`

```javascript
import React, { createContext, useState, useMemo } from 'react';
import { ThemeProvider as MuiThemeProvider } from '@mui/material/styles';
import { ConfigProvider } from 'antd';
import CssBaseline from '@mui/material/CssBaseline';
import { createAppTheme } from '../theme';

export const ThemeContext = createContext();

export const AppThemeProvider = ({ children }) => {
  const [mode, setMode] = useState('light'); // 'light', 'dark', 'semi-dark'
  const [layout, setLayout] = useState('default'); // 11 layout options

  const theme = useMemo(() => createAppTheme(mode), [mode]);

  const toggleTheme = () => {
    setMode(prev => {
      if (prev === 'light') return 'dark';
      if (prev === 'dark') return 'semi-dark';
      return 'light';
    });
  };

  const value = {
    mode,
    setMode,
    toggleTheme,
    layout,
    setLayout
  };

  return (
    <ThemeContext.Provider value={value}>
      <MuiThemeProvider theme={theme}>
        <ConfigProvider
          theme={{
            token: {
              colorPrimary: theme.palette.primary.main,
              borderRadius: 8
            }
          }}
        >
          <CssBaseline />
          {children}
        </ConfigProvider>
      </MuiThemeProvider>
    </ThemeContext.Provider>
  );
};
```

---

### **PHASE 2: Layout System** (Week 2-3)

#### 2.1 Create Base Layout Structure

**Directory Structure**:
```
src/
├── layouts/
│   ├── Default/           # Standard sidebar + header
│   ├── MiniSidebar/       # Collapsed sidebar
│   ├── MiniToggle/        # Toggle-able mini sidebar
│   ├── FullWidth/         # Full-width header
│   ├── Drawer/            # Drawer-style sidebar
│   ├── HorizontalDefault/ # Top navigation
│   └── Boxed/             # Boxed content layout
├── components/
│   ├── AppLayout/
│   │   ├── Sidebar/
│   │   ├── Header/
│   │   ├── Footer/
│   │   └── ContentArea/
│   └── navigation/
│       ├── VerticalNav/
│       └── HorizontalNav/
```

#### 2.2 Implement Default Layout (Primary)

**Create**: `src/layouts/Default/index.js`

```javascript
import React, { useState } from 'react';
import { Box, useTheme, useMediaQuery } from '@mui/material';
import Sidebar from '../../components/AppLayout/Sidebar';
import Header from '../../components/AppLayout/Header';
import Footer from '../../components/AppLayout/Footer';

const DefaultLayout = ({ children }) => {
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('md'));
  const [sidebarOpen, setSidebarOpen] = useState(!isMobile);

  return (
    <Box sx={{ display: 'flex', minHeight: '100vh' }}>
      <Sidebar 
        open={sidebarOpen} 
        onClose={() => setSidebarOpen(false)}
        variant={isMobile ? 'temporary' : 'permanent'}
      />
      
      <Box sx={{ flexGrow: 1, display: 'flex', flexDirection: 'column' }}>
        <Header 
          onMenuClick={() => setSidebarOpen(!sidebarOpen)}
        />
        
        <Box 
          component="main" 
          sx={{ 
            flexGrow: 1, 
            p: 3, 
            backgroundColor: theme.palette.background.default 
          }}
        >
          {children}
        </Box>
        
        <Footer />
      </Box>
    </Box>
  );
};

export default DefaultLayout;
```

#### 2.3 Create Sidebar Component

**Create**: `src/components/AppLayout/Sidebar/index.js`

```javascript
import React from 'react';
import {
  Drawer,
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  ListItemButton,
  Box,
  Typography,
  Divider,
  Collapse
} from '@mui/material';
import {
  Dashboard,
  Assessment,
  People,
  Settings,
  BarChart,
  Map,
  TableChart,
  ExpandLess,
  ExpandMore
} from '@mui/icons-material';
import { useNavigate, useLocation } from 'react-router-dom';

const SIDEBAR_WIDTH = 280;

const menuItems = [
  { 
    title: 'Dashboard', 
    icon: <Dashboard />, 
    path: '/' 
  },
  {
    title: 'Sales Analytics',
    icon: <Assessment />,
    children: [
      { title: 'Sales by Country', path: '/sales/country' },
      { title: 'Sales by Rep', path: '/sales/rep' },
      { title: 'Sales Reports', path: '/sales/reports' }
    ]
  },
  { 
    title: 'Charts', 
    icon: <BarChart />, 
    path: '/charts' 
  },
  { 
    title: 'Maps', 
    icon: <Map />, 
    path: '/maps' 
  },
  { 
    title: 'Master Data', 
    icon: <TableChart />,
    children: [
      { title: 'AEBF', path: '/master-data/aebf' },
      { title: 'Customer Merging', path: '/master-data/customer-merging' }
    ]
  },
  { 
    title: 'Settings', 
    icon: <Settings />, 
    path: '/settings' 
  }
];

const Sidebar = ({ open, onClose, variant }) => {
  const navigate = useNavigate();
  const location = useLocation();
  const [expandedItems, setExpandedItems] = React.useState({});

  const handleItemClick = (item) => {
    if (item.children) {
      setExpandedItems(prev => ({
        ...prev,
        [item.title]: !prev[item.title]
      }));
    } else if (item.path) {
      navigate(item.path);
      if (variant === 'temporary') {
        onClose();
      }
    }
  };

  const isActive = (path) => location.pathname === path;

  const renderMenuItem = (item, depth = 0) => {
    const hasChildren = item.children && item.children.length > 0;
    const expanded = expandedItems[item.title];

    return (
      <React.Fragment key={item.title}>
        <ListItem disablePadding sx={{ display: 'block' }}>
          <ListItemButton
            onClick={() => handleItemClick(item)}
            selected={isActive(item.path)}
            sx={{
              pl: depth * 2 + 2,
              borderRadius: 2,
              mx: 1,
              my: 0.5,
              '&.Mui-selected': {
                backgroundColor: 'primary.main',
                color: 'white',
                '&:hover': {
                  backgroundColor: 'primary.dark'
                },
                '& .MuiListItemIcon-root': {
                  color: 'white'
                }
              }
            }}
          >
            {item.icon && (
              <ListItemIcon 
                sx={{ 
                  minWidth: 40,
                  color: isActive(item.path) ? 'white' : 'text.secondary'
                }}
              >
                {item.icon}
              </ListItemIcon>
            )}
            <ListItemText 
              primary={item.title}
              primaryTypographyProps={{
                fontSize: 14,
                fontWeight: isActive(item.path) ? 600 : 500
              }}
            />
            {hasChildren && (
              expanded ? <ExpandLess /> : <ExpandMore />
            )}
          </ListItemButton>
        </ListItem>

        {hasChildren && (
          <Collapse in={expanded} timeout="auto" unmountOnExit>
            <List component="div" disablePadding>
              {item.children.map(child => renderMenuItem(child, depth + 1))}
            </List>
          </Collapse>
        )}
      </React.Fragment>
    );
  };

  const drawerContent = (
    <Box sx={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
      {/* Logo Area */}
      <Box sx={{ p: 3, textAlign: 'center' }}>
        <Typography variant="h5" fontWeight={700} color="primary">
          IPD Dashboard
        </Typography>
        <Typography variant="caption" color="text.secondary">
          Sales Analytics Platform
        </Typography>
      </Box>

      <Divider />

      {/* Navigation Menu */}
      <Box sx={{ flexGrow: 1, overflowY: 'auto', py: 2 }}>
        <List>
          {menuItems.map(item => renderMenuItem(item))}
        </List>
      </Box>

      <Divider />

      {/* Footer Area */}
      <Box sx={{ p: 2, textAlign: 'center' }}>
        <Typography variant="caption" color="text.secondary">
          Version 2.0.0
        </Typography>
      </Box>
    </Box>
  );

  return (
    <Drawer
      variant={variant}
      open={open}
      onClose={onClose}
      sx={{
        width: SIDEBAR_WIDTH,
        flexShrink: 0,
        '& .MuiDrawer-paper': {
          width: SIDEBAR_WIDTH,
          boxSizing: 'border-box',
          borderRight: '1px solid',
          borderColor: 'divider'
        }
      }}
    >
      {drawerContent}
    </Drawer>
  );
};

export default Sidebar;
```

#### 2.4 Create Header Component

**Create**: `src/components/AppLayout/Header/index.js`

```javascript
import React, { useContext } from 'react';
import {
  AppBar,
  Toolbar,
  IconButton,
  Box,
  Avatar,
  Menu,
  MenuItem,
  Typography,
  Badge
} from '@mui/material';
import {
  Menu as MenuIcon,
  Notifications,
  Settings,
  AccountCircle,
  Brightness4,
  Brightness7
} from '@mui/icons-material';
import { ThemeContext } from '../../../contexts/ThemeContext';

const Header = ({ onMenuClick }) => {
  const { mode, toggleTheme } = useContext(ThemeContext);
  const [anchorEl, setAnchorEl] = React.useState(null);

  return (
    <AppBar 
      position="sticky" 
      color="inherit" 
      elevation={1}
      sx={{ 
        zIndex: theme => theme.zIndex.drawer + 1,
        backgroundColor: 'background.paper',
        borderBottom: '1px solid',
        borderColor: 'divider'
      }}
    >
      <Toolbar>
        {/* Menu Toggle */}
        <IconButton
          edge="start"
          onClick={onMenuClick}
          sx={{ mr: 2 }}
        >
          <MenuIcon />
        </IconButton>

        {/* Search or Title */}
        <Typography variant="h6" component="div" sx={{ flexGrow: 1 }}>
          {/* Can add breadcrumbs or search here */}
        </Typography>

        {/* Theme Toggle */}
        <IconButton onClick={toggleTheme} sx={{ mr: 1 }}>
          {mode === 'dark' ? <Brightness7 /> : <Brightness4 />}
        </IconButton>

        {/* Notifications */}
        <IconButton sx={{ mr: 1 }}>
          <Badge badgeContent={4} color="error">
            <Notifications />
          </Badge>
        </IconButton>

        {/* Settings */}
        <IconButton sx={{ mr: 2 }}>
          <Settings />
        </IconButton>

        {/* User Profile */}
        <IconButton onClick={(e) => setAnchorEl(e.currentTarget)}>
          <Avatar sx={{ width: 32, height: 32 }}>
            <AccountCircle />
          </Avatar>
        </IconButton>

        <Menu
          anchorEl={anchorEl}
          open={Boolean(anchorEl)}
          onClose={() => setAnchorEl(null)}
        >
          <MenuItem>Profile</MenuItem>
          <MenuItem>My Account</MenuItem>
          <MenuItem>Logout</MenuItem>
        </Menu>
      </Toolbar>
    </AppBar>
  );
};

export default Header;
```

---

### **PHASE 3: Component Migration** (Week 4-5)

#### 3.1 Create Component Migration Strategy

**Priority Order**:
1. **Dashboard/Home Page** → Migrate first
2. **Sales Analytics Pages** → Core functionality
3. **Charts Components** → Keep ECharts or switch to Recharts
4. **Master Data Pages** → Last priority

#### 3.2 Example: Migrate Dashboard Page

**Create**: `src/pages/Dashboard/index.js` (MUI version)

```javascript
import React from 'react';
import {
  Grid,
  Card,
  CardContent,
  Typography,
  Box,
  Paper
} from '@mui/material';
import {
  TrendingUp,
  TrendingDown,
  AttachMoney,
  People
} from '@mui/icons-material';

// Reusable KPI Card Component
const KPICard = ({ title, value, change, icon, color }) => (
  <Card elevation={2}>
    <CardContent>
      <Box display="flex" justifyContent="space-between" alignItems="center">
        <Box>
          <Typography variant="body2" color="text.secondary" gutterBottom>
            {title}
          </Typography>
          <Typography variant="h4" fontWeight={600}>
            {value}
          </Typography>
          <Box display="flex" alignItems="center" mt={1}>
            {change > 0 ? (
              <TrendingUp fontSize="small" color="success" />
            ) : (
              <TrendingDown fontSize="small" color="error" />
            )}
            <Typography 
              variant="body2" 
              color={change > 0 ? 'success.main' : 'error.main'}
              ml={0.5}
            >
              {Math.abs(change)}%
            </Typography>
          </Box>
        </Box>
        <Box
          sx={{
            width: 56,
            height: 56,
            borderRadius: 2,
            backgroundColor: `${color}.lighter`,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center'
          }}
        >
          {icon}
        </Box>
      </Box>
    </CardContent>
  </Card>
);

const Dashboard = () => {
  return (
    <Box>
      <Typography variant="h4" fontWeight={600} mb={3}>
        Dashboard
      </Typography>

      <Grid container spacing={3}>
        {/* KPI Cards */}
        <Grid item xs={12} sm={6} md={3}>
          <KPICard
            title="Total Sales"
            value="$2.4M"
            change={12.5}
            icon={<AttachMoney />}
            color="primary"
          />
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <KPICard
            title="Active Customers"
            value="1,254"
            change={-3.2}
            icon={<People />}
            color="success"
          />
        </Grid>
        {/* Add more KPI cards */}

        {/* Charts */}
        <Grid item xs={12} md={8}>
          <Card elevation={2}>
            <CardContent>
              <Typography variant="h6" mb={2}>
                Sales Trend
              </Typography>
              {/* Your ECharts component here */}
            </CardContent>
          </Card>
        </Grid>

        <Grid item xs={12} md={4}>
          <Card elevation={2}>
            <CardContent>
              <Typography variant="h6" mb={2}>
                Top Products
              </Typography>
              {/* Product list */}
            </CardContent>
          </Card>
        </Grid>
      </Grid>
    </Box>
  );
};

export default Dashboard;
```

#### 3.3 Component Conversion Reference

**Ant Design → Material UI Mapping**:
```javascript
// Ant Design          →  Material UI
Table                 →  DataGrid (@mui/x-data-grid)
Button                →  Button
Input                 →  TextField
Select                →  Select
Modal                 →  Dialog
Card                  →  Card
Drawer                →  Drawer
Tabs                  →  Tabs
DatePicker            →  DatePicker (@mui/x-date-pickers)
Form                  →  Custom form or react-hook-form
Spin                  →  CircularProgress
message.success()     →  useSnackbar or Alert
```

---

### **PHASE 4: Advanced Features** (Week 6-7)

#### 4.1 Add Multiple Layout Support

**Create**: `src/contexts/LayoutContext.js`

```javascript
import React, { createContext, useState } from 'react';
import DefaultLayout from '../layouts/Default';
import MiniSidebarLayout from '../layouts/MiniSidebar';
import HorizontalLayout from '../layouts/HorizontalDefault';
// Import other layouts...

const LAYOUTS = {
  default: DefaultLayout,
  miniSidebar: MiniSidebarLayout,
  horizontal: HorizontalLayout
  // Add 11 layouts total
};

export const LayoutContext = createContext();

export const LayoutProvider = ({ children }) => {
  const [currentLayout, setCurrentLayout] = useState('default');
  
  const LayoutComponent = LAYOUTS[currentLayout];

  return (
    <LayoutContext.Provider value={{ currentLayout, setCurrentLayout }}>
      <LayoutComponent>{children}</LayoutComponent>
    </LayoutContext.Provider>
  );
};
```

#### 4.2 Add RTL Support

```javascript
// In theme/index.js
import { prefixer } from 'stylis';
import rtlPlugin from 'stylis-plugin-rtl';
import { CacheProvider } from '@emotion/react';
import createCache from '@emotion/cache';

const cacheRtl = createCache({
  key: 'muirtl',
  stylisPlugins: [prefixer, rtlPlugin]
});

export const RTLProvider = ({ children, direction = 'ltr' }) => {
  if (direction === 'rtl') {
    return <CacheProvider value={cacheRtl}>{children}</CacheProvider>;
  }
  return children;
};
```

#### 4.3 Add Authentication Pages (Optional)

**Create**: `src/pages/Auth/SignIn.js`

```javascript
import React from 'react';
import {
  Box,
  Card,
  CardContent,
  TextField,
  Button,
  Typography,
  Link,
  Divider
} from '@mui/material';
import { Google, Facebook } from '@mui/icons-material';

const SignIn = () => {
  return (
    <Box
      sx={{
        minHeight: '100vh',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: 'background.default'
      }}
    >
      <Card sx={{ maxWidth: 450, width: '100%', p: 2 }}>
        <CardContent>
          <Typography variant="h4" fontWeight={600} mb={1} textAlign="center">
            Sign In
          </Typography>
          <Typography variant="body2" color="text.secondary" textAlign="center" mb={3}>
            Sign in to continue to IPD Dashboard
          </Typography>

          {/* Social Login Buttons */}
          <Button
            fullWidth
            variant="outlined"
            startIcon={<Google />}
            sx={{ mb: 1 }}
          >
            Sign in with Google
          </Button>
          <Button
            fullWidth
            variant="outlined"
            startIcon={<Facebook />}
            sx={{ mb: 2 }}
          >
            Sign in with Facebook
          </Button>

          <Divider sx={{ my: 2 }}>OR</Divider>

          {/* Email/Password Form */}
          <TextField
            fullWidth
            label="Email Address"
            type="email"
            margin="normal"
          />
          <TextField
            fullWidth
            label="Password"
            type="password"
            margin="normal"
          />

          <Box textAlign="right" mb={2}>
            <Link href="#" variant="body2">
              Forgot Password?
            </Link>
          </Box>

          <Button fullWidth variant="contained" size="large">
            Sign In
          </Button>

          <Typography variant="body2" textAlign="center" mt={2}>
            Don't have an account?{' '}
            <Link href="/signup">Sign Up</Link>
          </Typography>
        </CardContent>
      </Card>
    </Box>
  );
};

export default SignIn;
```

---

### **PHASE 5: Optimization & Polish** (Week 8)

#### 5.1 Performance Optimizations

```javascript
// Lazy load routes
import { lazy, Suspense } from 'react';
import { CircularProgress, Box } from '@mui/material';

const Dashboard = lazy(() => import('./pages/Dashboard'));
const SalesByCountry = lazy(() => import('./pages/SalesByCountry'));

const LoadingFallback = () => (
  <Box display="flex" justifyContent="center" alignItems="center" minHeight="400px">
    <CircularProgress />
  </Box>
);

// In App.js
<Suspense fallback={<LoadingFallback />}>
  <Routes>
    <Route path="/" element={<Dashboard />} />
    <Route path="/sales/country" element={<SalesByCountry />} />
  </Routes>
</Suspense>
```

#### 5.2 Add Settings Panel (Crema Customizer)

**Create**: `src/components/AppLayout/SettingsDrawer/index.js`

```javascript
import React, { useContext } from 'react';
import {
  Drawer,
  Box,
  Typography,
  FormControl,
  FormLabel,
  RadioGroup,
  FormControlRadioGroup,
  Radio,
  Divider,
  IconButton
} from '@mui/material';
import { Close } from '@mui/icons-material';
import { ThemeContext } from '../../../contexts/ThemeContext';

const SettingsDrawer = ({ open, onClose }) => {
  const { mode, setMode, layout, setLayout } = useContext(ThemeContext);

  return (
    <Drawer anchor="right" open={open} onClose={onClose}>
      <Box sx={{ width: 320, p: 3 }}>
        <Box display="flex" justifyContent="space-between" alignItems="center" mb={3}>
          <Typography variant="h6">Customizer</Typography>
          <IconButton onClick={onClose}>
            <Close />
          </IconButton>
        </Box>

        {/* Theme Mode */}
        <FormControl component="fieldset" fullWidth sx={{ mb: 3 }}>
          <FormLabel component="legend">Theme Mode</FormLabel>
          <RadioGroup value={mode} onChange={(e) => setMode(e.target.value)}>
            <FormControlLabel value="light" control={<Radio />} label="Light" />
            <FormControlLabel value="dark" control={<Radio />} label="Dark" />
            <FormControlLabel value="semi-dark" control={<Radio />} label="Semi Dark" />
          </RadioGroup>
        </FormControl>

        <Divider sx={{ my: 2 }} />

        {/* Layout Type */}
        <FormControl component="fieldset" fullWidth>
          <FormLabel component="legend">Layout Type</FormLabel>
          <RadioGroup value={layout} onChange={(e) => setLayout(e.target.value)}>
            <FormControlLabel value="default" control={<Radio />} label="Default" />
            <FormControlLabel value="miniSidebar" control={<Radio />} label="Mini Sidebar" />
            <FormControlLabel value="horizontal" control={<Radio />} label="Horizontal" />
            <FormControlLabel value="drawer" control={<Radio />} label="Drawer" />
          </RadioGroup>
        </FormControl>
      </Box>
    </Drawer>
  );
};

export default SettingsDrawer;
```

#### 5.3 Add Dark Mode Support

Update your theme to handle semi-dark mode:

```javascript
// In theme/index.js
const semiDarkPalette = {
  primary: { main: '#0A8FDC' },
  secondary: { main: '#F04F47' },
  background: {
    default: '#F4F7FE',
    paper: '#313541'  // Dark sidebar with light content
  },
  text: {
    primary: '#313541',
    secondary: '#6F7C87'
  }
};

export const createAppTheme = (mode = 'light') => {
  let palette = lightPalette;
  if (mode === 'dark') palette = darkPalette;
  if (mode === 'semi-dark') palette = semiDarkPalette;
  
  // ... rest of theme config
};
```

---

## 🛠️ Implementation Checklist for Cursor

### **Week 1-2: Foundation**
- [ ] Install Material UI v7 and dependencies
- [ ] Install TypeScript types
- [ ] Create theme configuration (`src/theme/index.js`)
- [ ] Create ThemeContext with light/dark/semi-dark modes
- [ ] Create LayoutContext for layout switching
- [ ] Configure path aliases in tsconfig.json
- [ ] Update App.js to use theme providers

### **Week 2-3: Layout System**
- [ ] Create layout directory structure
- [ ] Build Default Layout (sidebar + header)
- [ ] Build Sidebar component with navigation
- [ ] Build Header component with user menu
- [ ] Build Footer component
- [ ] Add responsive behavior (mobile drawer)
- [ ] Create 3-5 additional layouts (mini, horizontal, drawer, etc.)

### **Week 4-5: Component Migration**
- [ ] Migrate Dashboard page to MUI
- [ ] Create reusable KPI Card component
- [ ] Migrate Sales by Country table (DataGrid)
- [ ] Migrate Sales by Rep page
- [ ] Keep ECharts or integrate Recharts
- [ ] Update chart components with new styling
- [ ] Migrate Master Data pages

### **Week 6-7: Advanced Features**
- [ ] Implement layout switcher
- [ ] Add Settings/Customizer drawer
- [ ] Create authentication pages (SignIn, SignUp, Forgot Password)
- [ ] Add error pages (404, 500, Maintenance)
- [ ] Implement RTL support (optional)
- [ ] Add multi-language support (optional)

### **Week 8: Polish & Optimization**
- [ ] Implement lazy loading for routes
- [ ] Add loading states and skeletons
- [ ] Optimize bundle size
- [ ] Test all layouts and themes
- [ ] Add animations and transitions
- [ ] Final QA and bug fixes

---

## 📊 Migration Priority Matrix

| Component | Current | Target | Priority | Effort |
|-----------|---------|--------|----------|--------|
| Dashboard | Custom | MUI Cards + Grid | 🔴 HIGH | 2 days |
| Sidebar Nav | Custom | MUI Drawer + List | 🔴 HIGH | 3 days |
| Header | Custom | MUI AppBar | 🔴 HIGH | 1 day |
| Sales Table | Ant Table | MUI DataGrid | 🟡 MEDIUM | 3 days |
| Charts | ECharts | Keep ECharts | 🟢 LOW | 1 day (styling) |
| Forms | Ant Form | MUI TextField | 🟡 MEDIUM | 2 days |
| Master Data | Ant Table | MUI DataGrid | 🟢 LOW | 2 days |

---

## 💰 Cost Analysis

### **Option A: DIY Migration (Recommended)**
- Material UI: **FREE** (MIT License)
- Development Time: **6-8 weeks**
- Total Cost: **$0** (just your time)

### **Option B: Purchase Crema Template**
- Crema License: **$29**
- Migration Time: **8-12 weeks**
- Learning Curve: **Medium**
- Total Cost: **$29 + time**

### **Option C: Hybrid (Best of Both)**
- Purchase Crema for reference: **$29**
- Build custom with Crema design patterns
- Total Cost: **$29 + 6-8 weeks time**
- ✅ Get professional code examples
- ✅ Copy layout patterns
- ✅ Customize to your needs

---

## 🎨 Design Reference & Resources

### **Crema Live Demos**
- MUI Version: https://cremawork.com/mui/
- Ant Design Version: https://cremawork.com/antd/

### **Material UI Documentation**
- MUI Components: https://mui.com/material-ui/getting-started/
- MUI X Data Grid: https://mui.com/x/react-data-grid/
- MUI Theming: https://mui.com/material-ui/customization/theming/

### **Color Palette (Crema-style)**
```
Primary Blue:   #0A8FDC
Secondary Red:  #F04F47
Success Green:  #52C41A
Warning Orange: #FAAD14
Error Red:      #F44336

Light BG:       #F4F7FE
Dark BG:        #1A1D2E
Paper Light:    #FFFFFF
Paper Dark:     #262939
```

### **Typography**
- **Font**: Inter or Roboto
- **Headings**: 600-700 weight
- **Body**: 400-500 weight
- **Size Scale**: 12px, 14px, 16px, 20px, 24px, 32px, 40px

---

## 🚨 Common Pitfalls to Avoid

1. **Don't remove Ant Design completely** - You can run both MUI + Ant Design together
2. **Don't migrate everything at once** - Use incremental approach
3. **Test responsiveness** - Crema is mobile-first
4. **Keep your backend unchanged** - Only UI changes needed
5. **Use layout context** - Don't hardcode layouts
6. **Implement dark mode from start** - Harder to add later
7. **Don't skip TypeScript** - Makes Cursor autocomplete better
8. **Use MUI sx prop** - More flexible than styled-components

---

## 📝 Cursor-Specific Tips

### **Leverage Cursor's AI**

**Example Prompts for Cursor:**

1. **"Convert this Ant Design table to MUI DataGrid"**
   ```
   Select your existing Ant Design table code, then:
   Cmd/Ctrl + K → "Convert this to Material UI DataGrid with same functionality"
   ```

2. **"Create a Crema-style sidebar component"**
   ```
   Cmd/Ctrl + L → "Create a Material UI sidebar like Crema with collapsible menu items"
   ```

3. **"Add dark mode support to this component"**
   ```
   Select component → Cmd/Ctrl + K → "Add dark mode support using MUI theme"
   ```

4. **"Generate TypeScript types for this component"**
   ```
   Cmd/Ctrl + K → "Add TypeScript types to this component"
   ```

### **Use Cursor Composer for Large Changes**
```
Cmd/Ctrl + I (Composer Mode)

Prompt: "Migrate the entire Dashboard page from Ant Design to Material UI, 
keeping all functionality but using Crema-style design with KPI cards, 
grid layout, and proper theming support"
```

---

## 🎯 Success Metrics

After migration, you should have:

✅ **11 Layout Variations** (default, mini, horizontal, etc.)
✅ **3 Theme Modes** (light, dark, semi-dark)
✅ **Responsive Design** (mobile, tablet, desktop)
✅ **Component Library** (50+ reusable MUI components)
✅ **Type Safety** (TypeScript throughout)
✅ **Modern UX** (animations, transitions, micro-interactions)
✅ **Authentication UI** (signin, signup, forgot password)
✅ **Settings Panel** (live customizer)
✅ **Performance** (lazy loading, code splitting)
✅ **Clean Codebase** (organized, maintainable)

---

## 🆘 Support Resources

1. **Material UI Discord**: https://discord.gg/mui
2. **React Community**: https://react.dev/community
3. **Stack Overflow**: Tag `material-ui` or `reactjs`
4. **Crema Support** (if purchased): Through ThemeForest

---

## 📌 Final Recommendations

**For Your Use Case (IPD26.10 Sales Dashboard):**

1. ✅ **Start with Option A** (Hybrid DIY approach)
2. ✅ **Consider purchasing Crema** ($29) for reference code
3. ✅ **Keep Ant Design** for complex components (tables, forms)
4. ✅ **Use Material UI** for layout and cards
5. ✅ **Keep ECharts** (works perfectly with MUI)
6. ✅ **Implement TypeScript** gradually
7. ✅ **Start with Default Layout** then add others
8. ✅ **Use Cursor Composer** for bulk migrations

**Timeline**: 6-8 weeks for full migration
**Risk Level**: Low (incremental approach)
**ROI**: High (modern UI, better UX, maintainable code)

---

## 🚀 Getting Started Tomorrow

**Day 1 Tasks (In Cursor):**

```bash
# 1. Install dependencies
npm install @mui/material@7 @emotion/react @emotion/styled @mui/icons-material@7

# 2. Create theme file
# Use Cursor to generate: src/theme/index.js

# 3. Create theme context
# Use Cursor to generate: src/contexts/ThemeContext.js

# 4. Update App.js to use providers

# 5. Create your first MUI page (Dashboard)
# Use Cursor Composer: "Create a Crema-style dashboard with KPI cards"
```

---

**Good luck with your migration! This plan should give you a clear roadmap to transform IPD26.10 into a modern Crema-style dashboard using Cursor.** 🎉

Would you like me to generate any specific component code or help with a particular phase?
