const express = require("express");
const xlsx = require("xlsx");
const cors = require("cors");
const path = require("path");
const fs = require("fs");

const app = express();
const PORT = 3001;

app.use(cors());
app.use(express.static(__dirname));
app.use('/public', express.static(path.join(__dirname, 'public')));
app.use(express.json()); // Add middleware to parse JSON bodies

// Add direct route for SalesOrderForm.html
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'SalesOrderForm.html'));
});

// New endpoint to save data to Excel file
app.post("/api/save", (req, res) => {
  try {
    const { type, data } = req.body;
    
    if (!type || !data) {
      return res.status(400).json({ success: false, message: "Missing type or data" });
    }
    
    console.log(`Saving new ${type} to Excel:`, data);
    
    // Read the Excel file
    const filePath = "Customers Database.xlsx";
    const workbook = xlsx.readFile(filePath);
    const sheetName = workbook.SheetNames[0];
    const sheet = workbook.Sheets[sheetName];
    const rows = xlsx.utils.sheet_to_json(sheet);
    
    // Create a new row based on the type
    let newRow = {};
    
    if (type === "salesRep") {
      newRow = {
        "Sales Rep": data.name,
        "Customer Name": "",
        "Location": "",
        "SKU Description": "",
        "Product Group": "",
        "Product End Use": "",
        "Number of Layers": "",
        "Micron 1 (µ)": "",
        "Substrate 1": "",
        "Micron 2 (µ)": "",
        "Substrate 2": "",
        "Micron 3 (µ)": "",
        "Substrate 3": "",
        "Micron 4 (µ)": "",
        "Substrate 4": ""
      };
    } else if (type === "customer") {
      newRow = {
        "Sales Rep": data.salesRep,
        "Customer Name": data.name,
        "Location": "",
        "SKU Description": "",
        "Product Group": "",
        "Product End Use": "",
        "Number of Layers": "",
        "Micron 1 (µ)": "",
        "Substrate 1": "",
        "Micron 2 (µ)": "",
        "Substrate 2": "",
        "Micron 3 (µ)": "",
        "Substrate 3": "",
        "Micron 4 (µ)": "",
        "Substrate 4": ""
      };
    } else if (type === "location") {
      newRow = {
        "Sales Rep": data.salesRep,
        "Customer Name": data.customer,
        "Location": data.name,
        "SKU Description": "",
        "Product Group": "",
        "Product End Use": "",
        "Number of Layers": "",
        "Micron 1 (µ)": "",
        "Substrate 1": "",
        "Micron 2 (µ)": "",
        "Substrate 2": "",
        "Micron 3 (µ)": "",
        "Substrate 3": "",
        "Micron 4 (µ)": "",
        "Substrate 4": ""
      };
    }
    
    // Add the new row
    rows.push(newRow);
    
    // Write back to the Excel file
    const newWorkbook = xlsx.utils.book_new();
    const newSheet = xlsx.utils.json_to_sheet(rows);
    xlsx.utils.book_append_sheet(newWorkbook, newSheet, sheetName);
    xlsx.writeFile(newWorkbook, filePath);
    
    console.log(`Successfully saved new ${type} to Excel`);
    
    // Return success response
    res.json({ success: true, message: `${type} saved successfully` });
  } catch (err) {
    console.error(`❌ Error saving to Excel:`, err.message);
    res.status(500).json({ success: false, message: err.message });
  }
});

// New endpoint to save structure data to Excel file
app.post("/api/save-structure", (req, res) => {
  try {
    const { data } = req.body;
    
    if (!data) {
      return res.status(400).json({ success: false, message: "Missing structure data" });
    }
    
    console.log("Saving new structure to Excel:", data);
    
    // Validate required fields
    if (!data.salesRep || !data.customer || !data.location || !data.productGroup || !data.endUse || !data.layerType) {
      return res.status(400).json({ success: false, message: "Missing required structure data fields" });
    }
    
    // Read the Excel file
    const filePath = "Customers Database.xlsx";
    const workbook = xlsx.readFile(filePath);
    const sheetName = workbook.SheetNames[0];
    const sheet = workbook.Sheets[sheetName];
    const rows = xlsx.utils.sheet_to_json(sheet);
    
    // Create a new row for the structure
    const newRow = {
      "Sales Rep": data.salesRep,
      "Customer Name": data.customer,
      "Location": data.location,
      "SKU Description": data.sku || "__temp_sku__",
      "Product Group": data.productGroup,
      "Product End Use": data.endUse,
      "Number of Layers": data.layerType,
      "Micron 1 (µ)": data.micron1 || "",
      "Substrate 1": data.structure1 || "",
      "Micron 2 (µ)": data.micron2 || "",
      "Substrate 2": data.structure2 || "",
      "Micron 3 (µ)": data.micron3 || "",
      "Substrate 3": data.structure3 || "",
      "Micron 4 (µ)": data.micron4 || "",
      "Substrate 4": data.structure4 || ""
    };
    
    // Add the new row
    rows.push(newRow);
    
    // Write back to the Excel file
    const newWorkbook = xlsx.utils.book_new();
    const newSheet = xlsx.utils.json_to_sheet(rows);
    xlsx.utils.book_append_sheet(newWorkbook, newSheet, sheetName);
    xlsx.writeFile(newWorkbook, filePath);
    
    console.log("Successfully saved new structure to Excel");
    
    // Return success response
    res.json({ success: true, message: "Structure saved successfully" });
  } catch (err) {
    console.error("❌ Error saving structure to Excel:", err.message);
    res.status(500).json({ success: false, message: err.message });
  }
});

app.get("/api/full", (req, res) => {
  try {
    console.log("Reading Excel file...");
    const workbook = xlsx.readFile("Customers Database.xlsx");
    const sheet = workbook.Sheets[workbook.SheetNames[0]];
    const rows = xlsx.utils.sheet_to_json(sheet);
    console.log(`Found ${rows.length} rows in the Excel file`);

    // Debug - Check column names in the first row
    if (rows.length > 0) {
      console.log("Available columns in Excel:", Object.keys(rows[0]).join(", "));
    }

    const nested = {};
    // First pass: Gather all data structures
    rows.forEach(row => {
      const rep = row["Sales Rep"];
      const customer = row["Customer Name"];
      const location = row["Location"];
      const skuDescription = row["SKU Description"];
      const productGroup = row["Product Group"];
      const endUse = row["Product End Use"];
      const layers = row["Number of Layers"];
      
      // Read structure data from columns with correct names
      const structureData = {
        micron1: row["Micron 1 (µ)"] || "",
        structure1: row["Substrate 1"] || "",
        micron2: row["Micron 2 (µ)"] || "",
        structure2: row["Substrate 2"] || "",
        micron3: row["Micron 3 (µ)"] || "",
        structure3: row["Substrate 3"] || "",
        micron4: row["Micron 4 (µ)"] || "",
        structure4: row["Substrate 4"] || ""
      };
      
      // Log all rows for Test 2/aaa for debugging
      if (rep === "Test 2" && customer === "aaa") {
        console.log("Sample data for Test 2/aaa:", {
          rep, customer, location, skuDescription, productGroup, endUse, layers,
          structureData: JSON.stringify(structureData)
        });
      }
      
      if (!rep || !customer) return;

      // Create nested object structure if it doesn't exist
      if (!nested[rep]) nested[rep] = {};
      if (!nested[rep][customer]) nested[rep][customer] = {};
      if (!nested[rep][customer][location]) nested[rep][customer][location] = {};
      if (!nested[rep][customer][location][skuDescription]) nested[rep][customer][location][skuDescription] = {};
      if (!nested[rep][customer][location][skuDescription][productGroup]) nested[rep][customer][location][skuDescription][productGroup] = {};
      if (!nested[rep][customer][location][skuDescription][productGroup][endUse]) {
        nested[rep][customer][location][skuDescription][productGroup][endUse] = {
          layers: [],
          structure: structureData,
          structures: {} // Store multiple structures for the same layer type
        };
      }
      
      // Add the layer if it doesn't exist
      if (layers && !nested[rep][customer][location][skuDescription][productGroup][endUse].layers.includes(layers)) {
        nested[rep][customer][location][skuDescription][productGroup][endUse].layers.push(layers);
        console.log(`Added layer "${layers}" for ${rep}/${customer}/${location}/${skuDescription}/${productGroup}/${endUse}`);
      }
      
      // Store multiple structures
      // Create a unique key based on the structure data
      const structureKey = `${structureData.micron1}-${structureData.structure1}-${structureData.micron2}-${structureData.structure2}-${structureData.micron3}-${structureData.structure3}-${structureData.micron4}-${structureData.structure4}`;
      
      // Store this structure with its unique key
      nested[rep][customer][location][skuDescription][productGroup][endUse].structures[structureKey] = structureData;
    });

    // Log detailed data structure
    console.log("Constructed nested data structure with:", Object.keys(nested).length, "sales reps");
    
    // Log full details for Test 2/aaa
    if (nested["Test 2"] && nested["Test 2"]["aaa"]) {
      console.log("\nDetailed structure for Test 2/aaa:");
      const locations = nested["Test 2"]["aaa"];
      Object.keys(locations).forEach(location => {
        console.log(`Location: ${location}`);
        const skus = locations[location];
        Object.keys(skus).forEach(sku => {
          console.log(`  SKU: ${sku}`);
          const productGroups = skus[sku];
          Object.keys(productGroups).forEach(pg => {
            console.log(`    Product Group: ${pg}`);
            const endUses = productGroups[pg];
            Object.keys(endUses).forEach(eu => {
              console.log(`      End Use: ${eu}`);
              console.log(`        Layers: ${endUses[eu].layers.join(', ')}`);
              console.log(`        Structures Count: ${Object.keys(endUses[eu].structures).length}`);
              // Log structure details
              Object.entries(endUses[eu].structures).forEach(([key, structure], idx) => {
                if (idx < 3) { // Limit to first 3 structures for brevity
                  console.log(`        Structure ${idx+1}: ${key}`);
                  console.log(`          Layer 1: ${structure.micron1}µ ${structure.structure1}`);
                  if (structure.micron2 && structure.structure2) {
                    console.log(`          Layer 2: ${structure.micron2}µ ${structure.structure2}`);
                  }
                  if (structure.micron3 && structure.structure3) {
                    console.log(`          Layer 3: ${structure.micron3}µ ${structure.structure3}`);
                  }
                  if (structure.micron4 && structure.structure4) {
                    console.log(`          Layer 4: ${structure.micron4}µ ${structure.structure4}`);
                  }
                }
              });
            });
          });
        });
      });
    }
    
    res.json(nested);
  } catch (err) {
    console.error("❌ Error loading Excel:", err.message);
    // Provide sample data on error
    const sampleData = {
      "Demo Rep": {
        "Demo Customer": {
          "Demo Location": {
            "Demo SKU": {
              "Sample Product Group": {
                "Sample End Use": {
                  layers: ["Mono"],
                  structure: {
                    micron1: "20",
                    structure1: "BOPP",
                    micron2: null,
                    structure2: null,
                    micron3: null,
                    structure3: null,
                    micron4: null,
                    structure4: null
                  },
                  structures: {}
                }
              }
            }
          }
        }
      }
    };
    console.log("Sending sample data due to error");
    res.json(sampleData);
  }
});

app.listen(PORT, () => {
  console.log(`✅ Server running at http://localhost:${PORT}`);
});
