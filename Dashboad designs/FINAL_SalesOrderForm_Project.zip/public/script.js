
document.addEventListener("DOMContentLoaded", function () {
  console.log("Form loaded");

  let excelData = [];

  window.onSalesRepChange = function (dropdown) {
    console.log("Sales Rep selected:", dropdown.value);
  };

  window.onCustomerChange = function (dropdown) {
    console.log("Customer selected:", dropdown.value);
    const salesRep = document.getElementById("salesRepDropdown").value;
    const location = document.getElementById("locationDropdown").value;
    populateSKUDropdown(excelData, dropdown.value, location);
  };

  window.onLocationChange = function (dropdown) {
    console.log("Location selected:", dropdown.value);
    const customer = document.getElementById("customerDropdown").value;
    populateSKUDropdown(excelData, customer, dropdown.value);
  };

  function populateSKUDropdown(data, selectedCustomer, selectedLocation) {
    const skuDropdown = document.getElementById("skuDropdown");
    skuDropdown.innerHTML = ""; // Clear existing

    const skus = [];

    data.forEach(row => {
      if (
        row["Customer Name"] === selectedCustomer &&
        row["Location"] === selectedLocation &&
        row.hasOwnProperty("SKU Description") &&
        typeof row["SKU Description"] === "string"
      ) {
        const sku = row["SKU Description"].trim();
        if (
          sku !== "" &&
          sku.toLowerCase() !== "undefined" &&
          sku.toLowerCase() !== "null"
        ) {
          skus.push(sku);
        }
      }
    });

    const uniqueSKUs = [...new Set(skus)];

    if (uniqueSKUs.length > 0) {
      uniqueSKUs.forEach(sku => {
        const option = document.createElement("option");
        option.value = sku;
        option.textContent = sku;
        skuDropdown.appendChild(option);
      });
    } else {
      const option = document.createElement("option");
      option.disabled = true;
      option.selected = true;
      option.textContent = "Not available";
      skuDropdown.appendChild(option);
    }

    skuDropdown.disabled = false;
  }

  fetch("/api/full")
    .then(res => res.json())
    .then(data => {
      console.log("Loaded Excel data", data);
      excelData = data;
    })
    .catch(err => console.error("Failed to load Excel data", err));
});


  // Populate Number of Layers dropdown: customer-specific first, then all fixed options
  
  function populateLayersDropdown(data, selectedCustomer, selectedLocation) {
    const layerDropdown = document.getElementById("layersDropdown");
    layerDropdown.innerHTML = "";

    const customerLayers = [];
    const allLayers = new Set(["Mono", "Duplex", "Triplex", "Quadriplex"]);

    data.forEach(row => {
      if (
        row["Customer Name"] === selectedCustomer &&
        row["Location"] === selectedLocation &&
        row["Number of Layers"] &&
        row["Number of Layers"].trim() !== "" &&
        row["Number of Layers"].trim().toLowerCase() !== "__add__"
      ) {
        customerLayers.push(row["Number of Layers"].trim());
      }
    });

    const uniqueCustomerLayers = [...new Set(customerLayers)].filter(
      val => !["__add__", "+ add new", "add new"].includes(val.toLowerCase())
    );

    uniqueCustomerLayers.forEach(layer => {
      const option = document.createElement("option");
      option.value = layer;
      option.textContent = layer;
      layerDropdown.appendChild(option);
    });

    if (uniqueCustomerLayers.length > 0) {
      const separator = document.createElement("option");
      separator.disabled = true;
      separator.textContent = "──────────";
      layerDropdown.appendChild(separator);
    }

    allLayers.forEach(layer => {
      const option = document.createElement("option");
      option.value = layer;
      option.textContent = layer;
      layerDropdown.appendChild(option);
    });

    layerDropdown.disabled = false;
  }

    const layerDropdown = document.getElementById("layersDropdown");
    layerDropdown.innerHTML = "";

    const customerLayers = [];
    const allLayers = new Set(["Mono", "Duplex", "Triplex", "Quadriplex"]);

    data.forEach(row => {
      if (
        row["Customer Name"] === selectedCustomer &&
        row["Location"] === selectedLocation &&
        row["Number of Layers"] &&
        row["Number of Layers"].trim() !== ""
      ) {
        customerLayers.push(row["Number of Layers"].trim());
      }
    });

    const uniqueCustomerLayers = [...new Set(customerLayers)];

    // Add customer-specific values
    uniqueCustomerLayers.forEach(layer => {
      const option = document.createElement("option");
      option.value = layer;
      option.textContent = layer;
      layerDropdown.appendChild(option);
    });

    // Add a separator
    if (uniqueCustomerLayers.length > 0) {
      const separator = document.createElement("option");
      separator.disabled = true;
      separator.textContent = "──────────";
      layerDropdown.appendChild(separator);
    }

    // Add all fixed options
    allLayers.forEach(layer => {
      const option = document.createElement("option");
      option.value = layer;
      option.textContent = layer;
      layerDropdown.appendChild(option);
    });

    layerDropdown.disabled = false;
  }

  // Populate Structure based on selected Number of Layers
  function populateStructureDropdown(data, selectedCustomer, selectedLocation, selectedLayers) {
    const structureDropdown = document.getElementById("structureDropdown");
    structureDropdown.innerHTML = "";

    const structures = [];

    data.forEach(row => {
      if (
        row["Customer Name"] === selectedCustomer &&
        row["Location"] === selectedLocation &&
        row["Number of Layers"] === selectedLayers &&
        row["Structure"] &&
        row["Structure"].trim() !== ""
      ) {
        structures.push(row["Structure"].trim());
      }
    });

    const uniqueStructures = [...new Set(structures)];

    if (uniqueStructures.length > 0) {
      uniqueStructures.forEach(structure => {
        const option = document.createElement("option");
        option.value = structure;
        option.textContent = structure;
        structureDropdown.appendChild(option);
      });
    } else {
      const option = document.createElement("option");
      option.disabled = true;
      option.selected = true;
      option.textContent = "Not available";
      structureDropdown.appendChild(option);
    }

    structureDropdown.disabled = false;
  }

  // Confirm structure modal add
  window.confirmStructure = function () {
    const input = document.getElementById("newStructureInput");
    const error = document.getElementById("structureError");
    const value = input.value.trim();

    const customer = document.getElementById("customerDropdown").value;
    const location = document.getElementById("locationDropdown").value;
    const layers = document.getElementById("layersDropdown").value;

    if (!value || !customer || !location || !layers) {
      error.textContent = "Please enter structure and ensure all related fields are selected.";
      return;
    }

    fetch("/api/save-structure", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        type: "structure",
        data: {
          salesRep: document.getElementById("salesRepDropdown").value,
          customer: customer,
          location: location,
          layers: layers,
          name: value
        }
      })
    })
      .then(res => res.json())
      .then(resp => {
        if (resp.success) {
          closeModal("modalStructure");
          input.value = "";
          error.textContent = "";
          // Re-trigger population
          populateStructureDropdown(excelData, customer, location, layers);
        } else {
          error.textContent = "Error saving structure.";
        }
      })
      .catch(() => {
        error.textContent = "Server error occurred.";
      });
  };
