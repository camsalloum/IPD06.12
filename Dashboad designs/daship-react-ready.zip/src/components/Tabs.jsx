import React from 'react';

const Tabs = ({ subTabs, activeTab, onTabChange }) => (
  <div className="tabs">
    {subTabs.map(tab => (
      <button
        key={tab}
        onClick={() => onTabChange(tab)}
        className={activeTab === tab ? 'active' : ''}
      >
        {tab}
      </button>
    ))}
  </div>
);

export default Tabs;
