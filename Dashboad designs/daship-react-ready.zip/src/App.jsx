import React, { useState } from 'react';
import './App.css';
import DivisionSelector from './components/DivisionSelector';
import Tabs from './components/Tabs';
import FilterPanel from './components/FilterPanel';
import ResultsTable from './components/ResultsTable';
import ErrorScreen from './components/ErrorScreen';

const App = () => {
  const [selectedDivision, setSelectedDivision] = useState(null);
  const [subTab, setSubTab] = useState("Financials");

  // Placeholder until hook is implemented
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const divisions = ['FP', 'SB', 'TF'];
  const subTabs = ['Financials', 'Sales'];

  const availableFilters = {
    years: ['2024', '2025'],
    months: ['Q1', 'Q2'],
    types: ['Actual', 'Budget']
  };

  const selectedFilters = {
    years: ['2024'],
    months: ['Q1'],
    types: ['Actual']
  };

  const toggleDummy = () => {};
  const handleRetry = () => {};

  if (loading) return <div className="loading">Loading...</div>;
  if (error) return <ErrorScreen error={error} onRetry={handleRetry} />;

  return (
    <div className="dashboard">
      {!selectedDivision ? (
        <DivisionSelector divisions={divisions} onSelect={setSelectedDivision} />
      ) : (
        <>
          <div className="header">
            <h2>Division: {selectedDivision}</h2>
            <button onClick={() => setSelectedDivision(null)}>Back</button>
          </div>
          <Tabs subTabs={subTabs} activeTab={subTab} onTabChange={setSubTab} />
          <FilterPanel
            filters={availableFilters}
            selected={selectedFilters}
            toggleYear={toggleDummy}
            toggleMonth={toggleDummy}
            toggleType={toggleDummy}
            onReset={() => {}}
          />
          <ResultsTable results={results} subTab={subTab} />
        </>
      )}
    </div>
  );
};

export default App;
