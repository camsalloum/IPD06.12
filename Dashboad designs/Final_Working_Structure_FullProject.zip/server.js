const express = require("express");
const cors = require("cors");
const bodyParser = require("body-parser");
const XLSX = require("xlsx");
const fs = require("fs");

const app = express();
const PORT = 3001;

app.use(cors());
app.use(bodyParser.json());
app.use(express.static("public"));

app.get("/", (req, res) => {
  res.sendFile(__dirname + "/SalesOrderForm.html");
});

app.post("/api/save-structure", (req, res) => {
  const { customer, location, salesRep, layers, structure } = req.body;
  if (!customer || !location || !layers || !structure) {
    return res.json({ success: false, error: "Missing data" });
  }

  const filePath = "./Customers Database.xlsx";
  const workbook = XLSX.readFile(filePath);
  const sheetName = "Structures"; // Assumes all go here
  const sheet = workbook.Sheets[sheetName] || XLSX.utils.aoa_to_sheet([]);

  const columns = [
    "Micron 1 (µ)", "Substrate 1",
    "Micron 2 (µ)", "Substrate 2",
    "Micron 3 (µ)", "Substrate 3",
    "Micron 4 (µ)", "Substrate 4"
  ];

  const segmentList = structure.split(" / ").map(pair => {
    const [micron, ...substrateParts] = pair.trim().split(" ");
    return [micron, substrateParts.join(" ")];
  });

  const newRow = {};
  for (let i = 0; i < segmentList.length; i++) {
    newRow[columns[i * 2]] = segmentList[i][0];     // Micron
    newRow[columns[i * 2 + 1]] = segmentList[i][1]; // Substrate
  }

  // Add meta fields
  newRow["Sales Rep"] = salesRep;
  newRow["Customer Name"] = customer;
  newRow["Location"] = location;
  newRow["Number of Layers"] = layers;

  // Append row
  const existing = XLSX.utils.sheet_to_json(sheet);
  existing.push(newRow);
  const updatedSheet = XLSX.utils.json_to_sheet(existing, { header: Object.keys(newRow) });

  workbook.Sheets[sheetName] = updatedSheet;
  if (!workbook.SheetNames.includes(sheetName)) workbook.SheetNames.push(sheetName);

  XLSX.writeFile(workbook, filePath);
  return res.json({ success: true });
});

// Optional: placeholder for full data retrieval
app.get("/api/full", (req, res) => {
  const filePath = "./Customers Database.xlsx";
  const workbook = XLSX.readFile(filePath);
  const sheetName = "Database";
  const sheet = workbook.Sheets[sheetName];
  const json = XLSX.utils.sheet_to_json(sheet);
  res.json(json);
});

app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});