
document.addEventListener("DOMContentLoaded", function () {
  console.log("Form loaded");

  window.openStructureModal = function () {
    const layerType = document.getElementById("layersDropdown").value;
    const container = document.getElementById("structureInputsContainer");
    container.innerHTML = "";

    let layerNum = layerType === "Mono" ? 1 :
                   layerType === "Duplex" ? 2 :
                   layerType === "Triplex" ? 3 :
                   layerType === "Quadriplex" ? 4 : 0;

    for (let i = 1; i <= layerNum; i++) {
      const micronLabel = document.createElement("label");
      micronLabel.textContent = `Layer ${i} Micron (µ):`;
      const micronInput = document.createElement("input");
      micronInput.type = "text";
      micronInput.id = `layer${i}MicronInput`;

      const structureLabel = document.createElement("label");
      structureLabel.textContent = `Layer ${i} Structure:`;
      const structureInput = document.createElement("input");
      structureInput.type = "text";
      structureInput.id = `layer${i}StructureInput`;

      container.appendChild(micronLabel);
      container.appendChild(micronInput);
      container.appendChild(structureLabel);
      container.appendChild(structureInput);
    }

    document.getElementById("modalStructure").style.display = "block";
  };

  window.saveStructureFromModal = function () {
    const layerCount = document.getElementById("layersDropdown").value;
    const customer = document.getElementById("customerDropdown").value;
    const location = document.getElementById("locationDropdown").value;
    const salesRep = document.getElementById("salesRepDropdown").value;

    const layerNum = layerCount === "Mono" ? 1 :
                     layerCount === "Duplex" ? 2 :
                     layerCount === "Triplex" ? 3 :
                     layerCount === "Quadriplex" ? 4 : 0;

    const segments = [];
    for (let i = 1; i <= layerNum; i++) {
      const micron = document.getElementById(`layer${i}MicronInput`).value.trim();
      const substrate = document.getElementById(`layer${i}StructureInput`).value.trim();
      if (!micron || !substrate) {
        alert("Please fill all layers");
        return;
      }
      segments.push(`${micron} ${substrate}`);
    }

    const fullStructure = segments.join(" / ");
    fetch("/api/save-structure", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        salesRep, customer, location, layers: layerCount, structure: fullStructure
      })
    })
    .then(res => res.json())
    .then(resp => {
      if (resp.success) {
        alert("Structure saved.");
        document.getElementById("modalStructure").style.display = "none";
      } else {
        alert("Save failed.");
      }
    })
    .catch(() => alert("Server error."));
  };
});
