# Implement the New UAE Dirham Symbol in Your Website & Apps
![Dirham Symbol Symbol](https://entarabi.com/wp-content/uploads/2025/03/Digital-Dirham-1.png)

## UAE Dirham Symbol

This repository provides the new **UAE Dirham (AED)** symbol in various formats, designed for easy integration into websites and applications. With a custom font utilizing the Unicode character **ê** (`U+00EA`), you can effortlessly customize the symbol's appearance using CSS.

---

## ✅ Unicode
The Unicode character (`&#x00EA;`) represents the new UAE Dirham symbol in this font package.

---

## 📦 Available Formats
This repository offers the UAE Dirham symbol in multiple formats:

### **Font Files**
- **TTF** (TrueType Font)
- **OTF** (OpenType Font)
- **WOFF** (Web Open Font Format)
- **WOFF2** (Web Open Font Format 2)

### **Vector Graphics**
- **SVG**

### **Raster Images**
- **PNG**

---

## 🚀 Installation via npm

You can install this package using npm:

```bash
npm i new-dirham-symbol
```

Or using Yarn:
```bash
yarn add new-dirham-symbol
```

---

## 🛠️ Usage Options

### **1. Using the Provided Stylesheet**
You can import the pre-built stylesheet directly into your project:

```css
@import '/node_modules/new-dirham-symbol/dist/uae-symbol.css';
```

Then use it in your HTML:

```html
<span class="dirham-symbol">&#xea;</span> 10,000
```

### **2. Defining the Font Yourself**
If you prefer, you can load the font manually using your own styles:

```css
@font-face {
    font-family: 'UAESymbol';
    src: url('uae-symbol.woff2') format('woff2'),
         url('uae-symbol.woff') format('woff'),
         url('uae-symbol.ttf') format('truetype');
}

.dirham-symbol {
    font-family: 'UAESymbol', sans-serif;
    font-size: inherit;
    color: inherit;
    font-weight: bold;
}
```

Use it in your HTML:

```html
<span class="dirham-symbol">&#xea;</span> 10,000
```

---

## 📏 Usage Guidelines
To maintain visual consistency, follow these guidelines:

- **Position**: Place the UAE Dirham symbol to the left of the numeral.
- **Spacing**: Keep a space between the symbol and the number.
- **Proportions**: Ensure the symbol maintains its original shape without distortion.
- **Alignment**: Match the symbol's height with the surrounding text.
- **Direction**: Follow the text direction.
- **Contrast**: Ensure sufficient contrast for legibility against the background.

---

## 🖼️ Demo Preview
Here’s how the symbol will look using this font:
![Screenshot of index.html](/demo/image/demo-page.PNG)  

```html
<span class="dirham-symbol">&#xea;</span> 79.00
```


## Connect with Me
[My LinkedIn Profile](https://linkedin.com/in/abdulrehmanyaser)

---

## 🧑‍💻 Contributing
Contributions are welcome! If you'd like to improve this package or add new features, feel free to open an issue or submit a pull request.

---
