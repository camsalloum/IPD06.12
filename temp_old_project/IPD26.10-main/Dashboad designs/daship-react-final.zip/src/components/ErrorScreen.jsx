import React from 'react';

const ErrorScreen = ({ error, onRetry }) => (
  <div className="error">
    <h3>Error Loading Data</h3>
    <p>{error}</p>
    <div className="error-actions">
      <button onClick={() => window.location.reload()}>Reload Page</button>
      <button onClick={onRetry}>Retry Loading Data</button>
    </div>
  </div>
);

export default ErrorScreen;
