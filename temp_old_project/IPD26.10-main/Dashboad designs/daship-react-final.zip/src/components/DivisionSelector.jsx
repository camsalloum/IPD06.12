import React from 'react';

const DivisionSelector = ({ divisions, onSelect }) => (
  <div className="division-selector">
    <h2>Select a Division</h2>
    {divisions.map(div => (
      <button key={div} onClick={() => onSelect(div)}>
        {div}
      </button>
    ))}
  </div>
);

export default DivisionSelector;
