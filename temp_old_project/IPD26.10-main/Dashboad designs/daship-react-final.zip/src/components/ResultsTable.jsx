import React from 'react';

const ResultsTable = ({ results, subTab }) => {
  if (!results.length) {
    return <div className="no-data-message">No data available for the selected filters</div>;
  }

  return (
    <div className="sheet-view">
      <table>
        <thead>
          <tr>
            <th>Year</th>
            <th>Month/Period</th>
            <th>Type</th>
            <th>{subTab === "Financials" ? "Sales Amount" : "Sales Volume"}</th>
          </tr>
        </thead>
        <tbody>
          {results.map((result, index) => (
            <tr key={index}>
              <td>{result.year}</td>
              <td>{result.month}</td>
              <td>{result.type}</td>
              <td className="numeric">{result.value.toLocaleString()}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default ResultsTable;
