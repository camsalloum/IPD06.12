
import { useState, useEffect } from 'react';
import * as XLSX from 'xlsx';

const useExcelData = (division, subTab) => {
  const [data, setData] = useState({});
  const [availableFilters, setAvailableFilters] = useState({ years: [], months: [], types: [] });
  const [selectedFilters, setSelectedFilters] = useState({ years: [], months: [], types: [] });
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const fileUrl = subTab === 'Financials' ? '/financials.xlsx' : '/sales.xlsx';

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        const res = await fetch(fileUrl);
        if (!res.ok) throw new Error('Failed to fetch Excel file');
        const buffer = await res.arrayBuffer();
        const workbook = XLSX.read(buffer, { type: 'buffer' });

        const parsed = {};
        workbook.SheetNames.forEach(name => {
          const sheet = workbook.Sheets[name];
          parsed[name] = XLSX.utils.sheet_to_json(sheet, { header: 1 });
        });

        setData(parsed);

        const sheet = parsed[division];
        if (sheet && sheet.length >= 3) {
          const years = [...new Set(sheet[0].slice(1))];
          const months = [...new Set(sheet[1].slice(1))];
          const types = [...new Set(sheet[2].slice(1))];

          setAvailableFilters({ years, months, types });
          setSelectedFilters({ years: [years[0]], months: [months[0]], types: [types[0]] });
        }

        setLoading(false);
      } catch (err) {
        setError(err.message);
        setLoading(false);
      }
    };

    if (division) fetchData();
  }, [division, subTab]);

  useEffect(() => {
    const sheet = data[division];
    if (!sheet || !selectedFilters.years.length || !selectedFilters.months.length || !selectedFilters.types.length) {
      setResults([]);
      return;
    }

    const matchingCols = [];
    for (let col = 1; col < sheet[0].length; col++) {
      const y = sheet[0][col];
      const m = sheet[1][col];
      const t = sheet[2][col];
      if (selectedFilters.years.includes(y) && selectedFilters.months.includes(m) && selectedFilters.types.includes(t)) {
        matchingCols.push(col);
      }
    }

    const label = subTab === 'Sales' ? 'Volume' : 'Sales';
    const rowIndex = sheet.findIndex((row, idx) => idx > 2 && row[0] === label);
    if (rowIndex === -1) {
      setResults([]);
      return;
    }

    const aggregated = {};
    for (const col of matchingCols) {
      const key = sheet[1][col] + '-' + sheet[0][col] + '-' + sheet[2][col];
      if (!aggregated[key]) {
        aggregated[key] = {
          month: sheet[1][col],
          year: sheet[0][col],
          type: sheet[2][col],
          value: 0
        };
      }
      aggregated[key].value += parseFloat(sheet[rowIndex][col]) || 0;
    }

    const sorted = Object.values(aggregated).sort((a, b) =>
      a.year.localeCompare(b.year) || a.month.localeCompare(b.month)
    );
    setResults(sorted);
  }, [data, division, selectedFilters, subTab]);

  return {
    availableFilters,
    selectedFilters,
    setSelectedFilters,
    results,
    loading,
    error
  };
};

export default useExcelData;
