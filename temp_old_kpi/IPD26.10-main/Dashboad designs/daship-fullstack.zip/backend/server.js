
const express = require('express');
const cors = require('cors');
const XLSX = require('xlsx');
const path = require('path');
const app = express();
const port = 3000;

app.use(cors());
app.use(express.static('public'));

function parseExcelFile(filePath) {
  const workbook = XLSX.readFile(filePath);
  const parsed = {};
  workbook.SheetNames.forEach(name => {
    const sheet = workbook.Sheets[name];
    parsed[name] = XLSX.utils.sheet_to_json(sheet, { header: 1 });
  });
  return parsed;
}

app.get('/api/financials', (req, res) => {
  try {
    const data = parseExcelFile(path.join(__dirname, '../public/financials.xlsx'));
    res.json(data);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/sales', (req, res) => {
  try {
    const data = parseExcelFile(path.join(__dirname, '../public/sales.xlsx'));
    res.json(data);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.listen(port, () => {
  console.log(`Backend server running at http://localhost:${port}`);
});
