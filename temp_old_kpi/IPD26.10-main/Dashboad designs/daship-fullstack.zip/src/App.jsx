
import React, { useState } from 'react';
import './App.css';
import DivisionSelector from './components/DivisionSelector';
import Tabs from './components/Tabs';
import FilterPanel from './components/FilterPanel';
import ResultsTable from './components/ResultsTable';
import ErrorScreen from './components/ErrorScreen';
import useExcelData from './hooks/useExcelData';

const App = () => {
  const [selectedDivision, setSelectedDivision] = useState(null);
  const [subTab, setSubTab] = useState("Financials");

  const {
    availableFilters,
    selectedFilters,
    setSelectedFilters,
    results,
    loading,
    error
  } = useExcelData(selectedDivision, subTab);

  const toggleYear = (year) => {
    const updated = selectedFilters.years.includes(year)
      ? selectedFilters.years.filter(y => y !== year)
      : [...selectedFilters.years, year];
    setSelectedFilters(prev => ({ ...prev, years: updated }));
  };

  const toggleMonth = (month) => {
    const updated = selectedFilters.months.includes(month)
      ? selectedFilters.months.filter(m => m !== month)
      : [...selectedFilters.months, month];
    setSelectedFilters(prev => ({ ...prev, months: updated }));
  };

  const toggleType = (type) => {
    const updated = selectedFilters.types.includes(type)
      ? selectedFilters.types.filter(t => t !== type)
      : [...selectedFilters.types, type];
    setSelectedFilters(prev => ({ ...prev, types: updated }));
  };

  const resetFilters = () => {
    setSelectedFilters({
      years: availableFilters.years.slice(0, 1),
      months: availableFilters.months.slice(0, 1),
      types: availableFilters.types.slice(0, 1),
    });
  };

  const handleRetry = () => {
    window.location.reload();
  };

  if (loading) return <div className="loading">Loading...</div>;
  if (error) return <ErrorScreen error={error} onRetry={handleRetry} />;

  return (
    <div className="dashboard">
      {!selectedDivision ? (
        <DivisionSelector divisions={['FP', 'SB', 'TF']} onSelect={setSelectedDivision} />
      ) : (
        <>
          <div className="header">
            <h2>Division: {selectedDivision}</h2>
            <button onClick={() => setSelectedDivision(null)}>Back</button>
          </div>
          <Tabs subTabs={['Financials', 'Sales']} activeTab={subTab} onTabChange={setSubTab} />
          <FilterPanel
            filters={availableFilters}
            selected={selectedFilters}
            toggleYear={toggleYear}
            toggleMonth={toggleMonth}
            toggleType={toggleType}
            onReset={resetFilters}
          />
          <ResultsTable results={results} subTab={subTab} />
        </>
      )}
    </div>
  );
};

export default App;
