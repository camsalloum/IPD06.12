import React from 'react';

const FilterPanel = ({
  filters, selected, toggleYear, toggleMonth, toggleType, onReset
}) => (
  <div className="filter-container">
    <div className="filter-section">
      <h3>Years</h3>
      <div className="filter-buttons">
        {filters.years.map(year => (
          <button
            key={year}
            onClick={() => toggleYear(year)}
            className={selected.years.includes(year) ? 'active' : ''}
          >
            {year}
          </button>
        ))}
      </div>
    </div>

    <div className="filter-section">
      <h3>Months/Periods</h3>
      <div className="filter-buttons months-grid">
        {filters.months.map(month => (
          <button
            key={month}
            onClick={() => toggleMonth(month)}
            className={selected.months.includes(month) ? 'active' : ''}
          >
            {month}
          </button>
        ))}
      </div>
    </div>

    <div className="filter-section">
      <h3>Data Type</h3>
      <div className="filter-buttons">
        {filters.types.map(type => (
          <button
            key={type}
            onClick={() => toggleType(type)}
            className={selected.types.includes(type) ? 'active' : ''}
          >
            {type}
          </button>
        ))}
      </div>
    </div>

    <div className="filter-actions">
      <button className="reset-button" onClick={onReset}>
        Reset Filters
      </button>
    </div>
  </div>
);

export default FilterPanel;
