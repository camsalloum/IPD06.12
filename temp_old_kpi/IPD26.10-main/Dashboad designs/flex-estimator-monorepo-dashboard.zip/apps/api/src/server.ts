import 'dotenv/config'
import Fastify from 'fastify'
import cors from '@fastify/cors'
import { z } from 'zod'
import { totalGSM, perLayerKg, rmCost, marginPrice, totalArea_m2, kgFromArea } from '@flex/calc-engine'

const PORT = Number(process.env.PORT || 8787)

const app = Fastify({ logger: false })
await app.register(cors, { origin: true })

app.get('/health', async () => ({ ok: true }))

// in-memory "db"
import materials from './data/materials.json' assert { type: 'json' }
import marginRules from './data/margin_rules.json' assert { type: 'json' }
import templatesIndex from './data/templates.index.json' assert { type: 'json' }

app.get('/api/v1/materials', async () => materials)
app.get('/api/v1/margin-rules', async () => marginRules)
app.get('/api/v1/templates', async () => {
  const list = templatesIndex.list
  return list
})
app.get('/api/v1/templates/:id', async (req, res) => {
  const { id } = req.params as any
  try {
    const tpl = (await import(`./data/templates/${id}.json`, { assert: { type: 'json' } })) as any
    return (tpl.default || tpl)
  } catch (e) {
    res.code(404)
    return { error: 'template not found' }
  }
})

const PricingReq = z.object({
  productGroup: z.string(),
  quantityMode: z.enum(['pieces','kpcs','sqm','lm','kg']),
  quantityValue: z.number().positive(),
  webWidth_mm: z.number().positive().optional(),
  layers: z.array(z.any()),
  geometry: z.any(),
})

app.post('/api/v1/pricing/preview', async (req, res) => {
  const parsed = PricingReq.safeParse(req.body)
  if (!parsed.success) {
    res.code(400)
    return parsed.error.format()
  }
  const R = parsed.data
  const tgsm = totalGSM(R.layers)
  const area_m2 = totalArea_m2({ ...(R.geometry as any), productGroup: R.productGroup as any })
  const kg = R.quantityMode === 'kg' ? R.quantityValue : kgFromArea(area_m2, tgsm)
  const split = perLayerKg(R.layers, kg)
  const priceByFamily = Object.fromEntries((materials as any[]).map(m => [m.family, m.price_kg]))
  const rm = rmCost(split, R.layers, priceByFamily, 0)
  const basis = (R.productGroup === 'laminate' || R.productGroup === 'monolayer') ? 'kg' : 'pieces'
  const qtyBasis = basis === 'kg' ? kg : (R.quantityMode === 'kpcs' ? R.quantityValue * 1000 : R.quantityValue)
  const sell = marginPrice(rm, marginRules as any, R.productGroup, basis as any, qtyBasis)
  return { tgsm, area_m2, kg, rm, sell, split }
})

app.listen({ port: PORT, host: '0.0.0.0' }).then(() => {
  console.log(`API listening on http://localhost:${PORT}`)
})
