import { CapacitorConfig } from '@capacitor/cli'
const config: CapacitorConfig = { appId: 'com.example.flexestimator', appName: 'Flexible Packaging Estimator', webDir: 'dist', bundledWebRuntime: false }
export default config
