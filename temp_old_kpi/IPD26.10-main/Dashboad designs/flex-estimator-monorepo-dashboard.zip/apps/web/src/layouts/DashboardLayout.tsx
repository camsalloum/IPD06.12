import { Link, NavLink, Outlet, useLocation } from 'react-router-dom'
import { Menu, Package2, Layers, Calculator, Settings, LineChart, Boxes } from 'lucide-react'
import { useState } from 'react'
import { cn } from '../lib/utils'

export function DashboardLayout(){
  const [open, setOpen] = useState(true)
  const loc = useLocation()
  return (
    <div className="min-h-screen grid grid-cols-[auto_1fr] bg-neutral-50">
      {/* Sidebar */}
      <aside className={cn('border-r border-neutral-200 bg-white transition-all', open ? 'w-64' : 'w-[4.5rem]')}>
        <div className="flex h-14 items-center justify-between px-3">
          <Link to="/dashboard" className="flex items-center gap-2">
            <Package2 className="h-5 w-5" />
            {open && <span className="font-semibold">Estimator</span>}
          </Link>
          <button className="rounded-md border p-1 text-neutral-600" onClick={()=>setOpen(o=>!o)}><Menu className="h-4 w-4"/></button>
        </div>
        <nav className="px-2 py-2 text-sm">
          <SideLink to="/dashboard" icon={<LineChart className="h-4 w-4" />}>Dashboard</SideLink>
          <SideLink to="/estimate" icon={<Calculator className="h-4 w-4" />}>New Estimate</SideLink>
          <SideLink to="/templates" icon={<Layers className="h-4 w-4" />}>Templates</SideLink>
          <SideLink to="/materials" icon={<Boxes className="h-4 w-4" />}>Materials</SideLink>
          <SideLink to="/settings" icon={<Settings className="h-4 w-4" />}>Settings</SideLink>
        </nav>
      </aside>

      {/* Main */}
      <div className="flex min-w-0 flex-col">
        <header className="flex h-14 items-center justify-between border-b bg-white px-4">
          <div className="text-sm text-neutral-500">Path: {loc.pathname}</div>
          <div className="flex items-center gap-2 text-sm">
            <a className="text-blue-600 hover:underline" href="http://localhost:8787/health" target="_blank" rel="noreferrer">API health</a>
          </div>
        </header>
        <main className="container max-w-[var(--container-w)] p-4">
          <Outlet />
        </main>
      </div>
    </div>
  )
}

function SideLink({ to, icon, children }:{ to: string; icon: React.ReactNode; children: React.ReactNode }){
  return (
    <NavLink to={to} className={({isActive})=>cn('mb-1 flex items-center gap-2 rounded-md px-2 py-2 hover:bg-neutral-100',
      isActive ? 'bg-neutral-100 font-medium text-neutral-900' : 'text-neutral-700')}>
      <span>{icon}</span>
      <span className="truncate">{children}</span>
    </NavLink>
  )
}
