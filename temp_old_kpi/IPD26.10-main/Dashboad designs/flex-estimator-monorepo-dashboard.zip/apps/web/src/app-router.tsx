import { createBrowserRouter, RouterProvider } from 'react-router-dom'
import { DashboardLayout } from './layouts/DashboardLayout'
import { Dashboard } from './pages/Dashboard'
import { EstimatorPage } from './pages/EstimatorPage'

const router = createBrowserRouter([
  {
    path: '/',
    element: <DashboardLayout />,
    children: [
      { index: true, element: <Dashboard /> },
      { path: 'dashboard', element: <Dashboard /> },
      { path: 'estimate', element: <EstimatorPage /> },
      { path: '*', element: <div className="p-6">Not found</div> }
    ]
  }
])

export function AppRouter(){
  return <RouterProvider router={router} />
}
