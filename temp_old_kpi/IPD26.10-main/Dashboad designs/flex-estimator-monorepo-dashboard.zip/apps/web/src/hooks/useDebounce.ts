import { useEffect, useRef } from 'react'
export function useDebouncedEffect(effect: () => void, deps: any[], delay = 600) {
  const first = useRef(true)
  useEffect(() => { if (first.current) { first.current = false } const h = setTimeout(effect, delay); return () => clearTimeout(h) }, deps)
}
