import localforage from 'localforage'
export type DraftRecord = { id: string; name: string; createdAt: number; updatedAt: number; payload: any }
const DB = localforage.createInstance({ name: 'flex-estimator', storeName: 'drafts' })
export async function saveDraft(name: string, payload: any, id?: string) {
  const draftId = id ?? cryptoRandomId()
  const now = Date.now()
  const rec: DraftRecord = { id: draftId, name, createdAt: now, updatedAt: now, payload }
  await DB.setItem(draftId, rec)
  return rec
}
export function loadDraft(id: string) { return DB.getItem(id) as Promise<DraftRecord | null> }
export async function listDrafts() {
  const keys = await DB.keys()
  const items: DraftRecord[] = []
  for (const k of keys) { const it = await DB.getItem(k); if (it) items.push(it as DraftRecord) }
  return items.sort((a,b)=>b.updatedAt - a.updatedAt)
}
export function deleteDraft(id: string) { return DB.removeItem(id) }
export function cryptoRandomId(len = 12) { const arr = new Uint8Array(len); crypto.getRandomValues(arr); return Array.from(arr).map(b=>b.toString(16).padStart(2,'0')).join('') }
