import { create } from 'zustand'
import { immer } from 'zustand/middleware/immer'
import type { AnyGeometry, Layer, MarginRule, MaterialFamily, TemplateDef } from '@flex/calc-engine'

interface AppState {
  materials: MaterialFamily[]
  marginRules: MarginRule[]
  templates: TemplateDef[]
  selectedGroup: string
  selectedTemplateId: string | null
  layers: Layer[]
  geometry: AnyGeometry | null
  init: (payload: Partial<AppState>) => void
  setGroup: (g: string) => void
  setTemplate: (id: string) => void
  setLayers: (layers: Layer[]) => void
  setGeometry: (geo: AnyGeometry) => void
}

export const useAppStore = create<AppState>()(
  immer((set) => ({
    materials: [],
    marginRules: [],
    templates: [],
    selectedGroup: 'laminate',
    selectedTemplateId: null,
    layers: [],
    geometry: null,
    init: (payload) => set(state => Object.assign(state, payload)),
    setGroup: (g) => set(state => { state.selectedGroup = g }),
    setTemplate: (id) => set(state => { state.selectedTemplateId = id }),
    setLayers: (layers) => set(state => { state.layers = layers }),
    setGeometry: (geo) => set(state => { state.geometry = geo }),
  }))
)
