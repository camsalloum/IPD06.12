export async function loadDefaults() {
  const API = import.meta.env.VITE_API_BASE || 'http://localhost:8787'
  async function get(path: string) {
    try {
      const r = await fetch(`${API}${path}`)
      if (!r.ok) throw new Error('bad status')
      return await r.json()
    } catch (e) {
      return null
    }
  }
  // Try API first
  const [materials, marginRules, templatesList] = await Promise.all([
    get('/api/v1/materials'),
    get('/api/v1/margin-rules'),
    get('/api/v1/templates'),
  ])
  // Fallback to local JSON if needed
  const local = await import('../data/fallback')
  const materialsFinal = materials ?? local.materials
  const marginRulesFinal = marginRules ?? local.marginRules
  const templatesFinal = templatesList ?? local.templatesIndex.list
  return { materials: materialsFinal, marginRules: marginRulesFinal, templates: templatesFinal }
}
