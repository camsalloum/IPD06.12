import { useEffect } from 'react'
import { Button } from './components/ui/button'
import { Card } from './components/ui/card'
import { useAppStore } from './state/store'
import { loadDefaults } from './state/defaults'
import { Estimator } from './features/Estimator'

export default function App() {
  const init = useAppStore(s => s.init)
  useEffect(() => { loadDefaults().then(init) }, [init])
  return (
    <div className="container max-w-[var(--container-w)] py-6">
      <header className="mb-6 flex items-center justify-between">
        <h1 className="text-2xl font-semibold">Flexible Packaging Estimator</h1>
        <div className="flex gap-2">
          <a href="https://ui.shadcn.com" target="_blank" rel="noreferrer" className="text-sm text-blue-600 hover:underline">shadcn/ui</a>
          <a href="http://localhost:8787/health" target="_blank" rel="noreferrer" className="text-sm text-blue-600 hover:underline">API health</a>
        </div>
      </header>
      <Estimator />
      <footer className="mt-10 text-xs text-neutral-500">
        <p>Monorepo starter — Web + API + Shared calc-engine.</p>
      </footer>
    </div>
  )
}
