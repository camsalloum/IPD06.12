import { Estimator } from '../features/Estimator'
export function EstimatorPage(){ return <Estimator /> }
