import { useEffect, useState } from 'react'
import { Card } from '../components/ui/card'
import { Button } from '../components/ui/button'
import { Link } from 'react-router-dom'
import { listDrafts } from '../utils/storage'
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, BarChart, Bar } from 'recharts'

export function Dashboard(){
  const [drafts, setDrafts] = useState<{id:string; name:string}[]>([])
  useEffect(()=>{ listDrafts().then(d=>setDrafts(d.slice(0,5).map(x=>({id:x.id, name:x.name})))) }, [])

  const salesData = [
    { month: 'Jan', kg: 120, margin: 18 },
    { month: 'Feb', kg: 160, margin: 17 },
    { month: 'Mar', kg: 140, margin: 19 },
    { month: 'Apr', kg: 210, margin: 16 },
    { month: 'May', kg: 180, margin: 18 },
    { month: 'Jun', kg: 230, margin: 17 },
  ]

  return (
    <div className="space-y-6">
      {/* header */}
      <div className="flex flex-col items-start justify-between gap-3 md:flex-row md:items-center">
        <div>
          <h1 className="text-2xl font-semibold">Dashboard</h1>
          <p className="text-sm text-neutral-500">Quick access to new estimates, recent drafts, and performance.</p>
        </div>
        <div className="flex gap-2">
          <Link to="/estimate"><Button variant="primary">New Estimate</Button></Link>
          <Button>Import JSON</Button>
        </div>
      </div>

      {/* KPI cards */}
      <div className="grid grid-cols-1 gap-4 md:grid-cols-4">
        <Card className="p-4">
          <p className="text-xs text-neutral-500">Active Drafts</p>
          <p className="mt-1 text-2xl font-semibold">{drafts.length}</p>
        </Card>
        <Card className="p-4">
          <p className="text-xs text-neutral-500">Avg Total GSM</p>
          <p className="mt-1 text-2xl font-semibold">~110</p>
        </Card>
        <Card className="p-4">
          <p className="text-xs text-neutral-500">Common Structure</p>
          <p className="mt-1 text-2xl font-semibold">Triplex</p>
        </Card>
        <Card className="p-4">
          <p className="text-xs text-neutral-500">Est. Margin</p>
          <p className="mt-1 text-2xl font-semibold">18%</p>
        </Card>
      </div>

      {/* charts */}
      <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
        <Card className="p-4">
          <p className="mb-2 text-sm font-medium">Monthly kg</p>
          <div className="h-56 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={salesData}>
                <XAxis dataKey="month" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="kg" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </Card>
        <Card className="p-4">
          <p className="mb-2 text-sm font-medium">Avg Margin %</p>
          <div className="h-56 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={salesData}>
                <XAxis dataKey="month" />
                <YAxis />
                <Tooltip />
                <Line type="monotone" dataKey="margin" />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </Card>
      </div>

      {/* recent drafts */}
      <Card className="p-4">
        <div className="mb-2 flex items-center justify-between">
          <p className="text-sm font-medium">Recent drafts</p>
          <Link to="/estimate" className="text-sm text-blue-600 hover:underline">All drafts →</Link>
        </div>
        {!drafts.length ? (
          <p className="text-sm text-neutral-500">No drafts yet — create your first estimate.</p>
        ) : (
          <ul className="divide-y">
            {drafts.map(d => (
              <li key={d.id} className="flex items-center justify-between py-2 text-sm">
                <span className="truncate">{d.name}</span>
                <Link to="/estimate" className="text-blue-600 hover:underline">Open</Link>
              </li>
            ))}
          </ul>
        )}
      </Card>
    </div>
  )
}
