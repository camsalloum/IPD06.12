import { useEffect, useMemo, useState } from 'react'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { Button } from '../components/ui/button'
import { Card } from '../components/ui/card'
import { useAppStore } from '../state/store'
import { loadDefaults } from '../state/defaults'
import { gsmForLayer, totalGSM, totalArea_m2, kgFromArea, lengthFromKg, perLayerKg, rmCost, marginPrice } from '@flex/calc-engine'
import type { AnyGeometry, Layer, SubstrateLayer, CoatingLayer, ProductGroup } from '@flex/calc-engine'
import { saveDraft, listDrafts, loadDraft, deleteDraft } from '../utils/storage'
import { useDebouncedEffect } from '../hooks/useDebounce'
import { walSchema, sleeveSchema, genericSchema, pouch3ssSchema, pouchSUPSchema, pouchSideGussetSchema } from '../validation/schemas'

const API = import.meta.env.VITE_API_BASE || 'http://localhost:8787'

type RHFMode = 'wal' | 'sleeve' | 'laminate' | 'monolayer' | 'pouch_3ss' | 'pouch_sup_doyen' | 'pouch_sup_k' | 'pouch_side_gusset'
function schemaFor(group: RHFMode) {
  switch (group) {
    case 'wal': return walSchema
    case 'sleeve': return sleeveSchema
    case 'laminate':
    case 'monolayer': return genericSchema
    case 'pouch_3ss': return pouch3ssSchema
    case 'pouch_sup_doyen':
    case 'pouch_sup_k': return pouchSUPSchema
    case 'pouch_side_gusset': return pouchSideGussetSchema
    default: return genericSchema
  }
}

export function Estimator() {
  const { materials, marginRules, templates, selectedGroup, selectedTemplateId, layers } = useAppStore()
  const setGroup = useAppStore(s => s.setGroup)
  const setTemplate = useAppStore(s => s.setTemplate)
  const setLayers = useAppStore(s => s.setLayers)
  const setGeometry = useAppStore(s => s.setGeometry)

  const [jobName, setJobName] = useState('My First Estimate')
  const [drafts, setDrafts] = useState<{id:string; name:string}[]>([])
  const [currentDraftId, setCurrentDraftId] = useState<string | null>(null)

  const groupOptions = [
    { value: 'wal', label: 'WAL' },
    { value: 'sleeve', label: 'Sleeve' },
    { value: 'laminate', label: 'Laminate' },
    { value: 'monolayer', label: 'Monolayer' },
    { value: 'pouch_3ss', label: 'Pouch – 3SS' },
    { value: 'pouch_sup_doyen', label: 'Pouch – SUP Doyen' },
    { value: 'pouch_sup_k', label: 'Pouch – SUP K' },
    { value: 'pouch_side_gusset', label: 'Pouch – Side Gusset' },
  ] as const

  const templateOptions = useMemo(() => templates.filter(t => t.product_group === selectedGroup).map(t => ({ value: t.id, label: t.id.replace(/_/g,' ') })), [templates, selectedGroup])

  async function fetchTemplate(id: string) {
    const r = await fetch(`${API}/api/v1/templates/${id}`)
    if (r.ok) return await r.json()
    // fallback to local
    const local = await import(`../data/templates/${id}.json`)
    return local.default
  }

  function makeInitialLayers(tpl: any): Layer[] {
    const chooseDensity = (fam: string) => materials.find((m: any) => m.family === fam)?.density_gcc ?? 1.0
    const chooseFamily = (allowed: string[]) => allowed[0]
    const rnd = () => Math.random().toString(36).slice(2)
    return tpl.roles.map((r: any) => {
      if (r.role === 'SUBSTRATE') {
        const fam = chooseFamily(r.allowed)
        return { id: rnd(), role: 'SUBSTRATE', slot: r.slot, materialFamily: fam, thickness_um: 12, density_gcc: chooseDensity(fam), allowedFamilies: r.allowed } as SubstrateLayer
      } else {
        return { id: rnd(), role: 'COATING_GSM', type: r.type, gsm: r.default_gsm } as CoatingLayer
      }
    })
  }

  async function handleChooseTemplate(id: string) {
    setTemplate(id)
    const tpl = await fetchTemplate(id)
    const initLayers = makeInitialLayers(tpl)
    setLayers(initLayers)
  }

  const defaultGeo: Record<RHFMode, any> = {
    wal: { productGroup: 'wal', quantityMode: 'pieces', quantityValue: 15000, cutLength_mm: 200, height_mm: 100, overlap_mm: 15, webWidth_mm: 320 },
    sleeve: { productGroup: 'sleeve', quantityMode: 'pieces', quantityValue: 15000, layflat_mm: 150, cutHeight_mm: 100, webWidth_mm: 300 },
    laminate: { productGroup: 'laminate', quantityMode: 'pieces', quantityValue: 15000, width_mm: 200, height_mm: 470, sideSeal_mm: 0, bottomSeal_mm: 0, overlap_mm: 0, webWidth_mm: 320 },
    monolayer: { productGroup: 'monolayer', quantityMode: 'pieces', quantityValue: 15000, width_mm: 200, height_mm: 470, sideSeal_mm: 0, bottomSeal_mm: 0, overlap_mm: 0, webWidth_mm: 320 },
    pouch_3ss: { productGroup: 'pouch_3ss', quantityMode: 'pieces', quantityValue: 15000, W_mm: 200, H_mm: 300, sideSeal_mm: 10, bottomSeal_mm: 10, header_mm: 0, zipperAllowance_mm: 0, webWidth_mm: 320 },
    pouch_sup_doyen: { productGroup: 'pouch_sup_doyen', quantityMode: 'pieces', quantityValue: 15000, W_mm: 200, H_mm: 300, sideSeal_mm: 10, gussetG_mm: 35, zipperAllowance_mm: 10, webWidth_mm: 320 },
    pouch_sup_k: { productGroup: 'pouch_sup_k', quantityMode: 'pieces', quantityValue: 15000, W_mm: 200, H_mm: 300, sideSeal_mm: 10, gussetG_mm: 35, zipperAllowance_mm: 10, webWidth_mm: 320 },
    pouch_side_gusset: { productGroup: 'pouch_side_gusset', quantityMode: 'pieces', quantityValue: 15000, F_mm: 130, G_mm: 35, H_mm: 300, bottomAllowance_mm: 10, zipperAllowance_mm: 10, webWidth_mm: 320 },
  }

  const form = useForm<any>({
    resolver: zodResolver(schemaFor(selectedGroup as RHFMode)),
    defaultValues: defaultGeo[selectedGroup as RHFMode] ?? defaultGeo.laminate
  })

  useEffect(() => { form.reset(defaultGeo[selectedGroup as RHFMode] ?? defaultGeo.laminate) }, [selectedGroup]) // reset on group change
  useEffect(() => { const sub = form.watch(vals => setGeometry(vals as any)); return () => sub.unsubscribe() }, [form, setGeometry])

  // autosave
  useEffect(() => { refreshDrafts() }, [])
  useDebouncedEffect(() => {
    const payload = { jobName, selectedGroup, selectedTemplateId, layers, geometry: form.getValues() }
    saveDraft(jobName, payload, currentDraftId ?? undefined).then(rec => { setCurrentDraftId(rec.id); refreshDrafts() })
  }, [jobName, selectedGroup, selectedTemplateId, layers, form.watch()], 800)

  async function refreshDrafts() {
    const list = await listDrafts()
    setDrafts(list.map(d => ({ id: d.id, name: d.name })))
  }

  const values = form.getValues()
  const tgsm = totalGSM(layers)
  const area_m2 = totalArea_m2({ ...(values as any), productGroup: selectedGroup as ProductGroup })
  const kg = values.quantityMode === 'kg' ? values.quantityValue : kgFromArea(area_m2, tgsm)
  const lm = lengthFromKg(kg, tgsm, (values as any).webWidth_mm ?? 0)
  const kgSplit = perLayerKg(layers, kg)
  const priceByFamily = Object.fromEntries(materials.map(m => [m.family, m.price_kg]))
  const rm = rmCost(kgSplit, layers, priceByFamily, 0)
  const basis = selectedGroup === 'laminate' || selectedGroup === 'monolayer' ? 'kg' : 'pieces'
  const qtyBasis = basis === 'kg' ? kg : (values.quantityMode === 'kpcs' ? values.quantityValue * 1000 : values.quantityValue)
  const sell = marginPrice(rm, marginRules as any, selectedGroup as any, basis as any, qtyBasis)

  return (
    <div className="grid grid-cols-1 gap-4 md:grid-cols-12">
      {/* Left: Product/Template/Geometry */}
      <Card className="md:col-span-4 p-4">
        <h2 className="mb-3 text-lg font-semibold">1) Product & Geometry</h2>
        <div className="mb-3">
          <label className="text-sm font-medium">Job name</label>
          <input className="mt-1 w-full rounded border border-neutral-300 px-2 py-1 text-sm" value={jobName} onChange={e=>setJobName(e.target.value)} />
        </div>
        <div className="mb-3">
          <label className="text-sm font-medium">Product Group</label>
          <select className="mt-1 w-full rounded border border-neutral-300 px-2 py-1" value={selectedGroup} onChange={(e)=>setGroup(e.target.value)}>
            {groupOptions.map(g => <option key={g.value} value={g.value}>{g.label}</option>)}
          </select>
        </div>
        <div className="mb-3">
          <label className="text-sm font-medium">Template</label>
          <select className="mt-1 w-full rounded border border-neutral-300 px-2 py-1" value={selectedTemplateId ?? ''} onChange={(e)=>handleChooseTemplate(e.target.value)}>
            <option value="" disabled>Select template</option>
            {templateOptions.map(t => <option key={t.value} value={t.value}>{t.label}</option>)}
          </select>
        </div>

        {/* Geometry form */}
        <form className="space-y-2" onSubmit={e=>e.preventDefault()}>
          <div>
            <label className="text-sm">Quantity Mode</label>
            <select className="mt-1 w-full rounded border border-neutral-300 px-2 py-1" {...form.register('quantityMode')}>
              <option value="pieces">pieces</option>
              <option value="kpcs">kpcs</option>
              <option value="sqm">sqm</option>
              <option value="lm">lm</option>
              <option value="kg">kg</option>
            </select>
          </div>
          <Num name="quantityValue" label="Quantity Value" form={form} />

          {selectedGroup === 'wal' && (<>
            <Num name="cutLength_mm" label="Cut length (mm)" form={form} />
            <Num name="height_mm" label="Height (mm)" form={form} />
            <Num name="overlap_mm" label="Overlap (mm)" form={form} />
            <Num name="webWidth_mm" label="Web width (mm)" form={form} />
          </>)}
          {selectedGroup === 'sleeve' && (<>
            <Num name="layflat_mm" label="Layflat (mm)" form={form} />
            <Num name="circumference_mm" label="Circumference (mm)" form={form} />
            <Num name="cutHeight_mm" label="Cut height (mm)" form={form} />
            <Num name="webWidth_mm" label="Web width (mm)" form={form} />
          </>)}
          {(selectedGroup === 'laminate' || selectedGroup === 'monolayer') && (<>
            <Num name="width_mm" label="Width (mm)" form={form} />
            <Num name="height_mm" label="Height (mm)" form={form} />
            <Num name="sideSeal_mm" label="Side Seal (mm)" form={form} />
            <Num name="bottomSeal_mm" label="Bottom Seal (mm)" form={form} />
            <Num name="overlap_mm" label="Overlap (mm)" form={form} />
            <Num name="webWidth_mm" label="Web width (mm)" form={form} />
          </>)}
          {selectedGroup === 'pouch_3ss' && (<>
            <Num name="W_mm" label="Width W (mm)" form={form} />
            <Num name="H_mm" label="Height H (mm)" form={form} />
            <Num name="sideSeal_mm" label="Side Seal (mm)" form={form} />
            <Num name="bottomSeal_mm" label="Bottom Seal (mm)" form={form} />
            <Num name="header_mm" label="Header Allowance (mm)" form={form} />
            <Num name="zipperAllowance_mm" label="Zipper Allowance (mm)" form={form} />
            <Num name="webWidth_mm" label="Web width (mm)" form={form} />
          </>)}
          {(selectedGroup === 'pouch_sup_doyen' || selectedGroup === 'pouch_sup_k') && (<>
            <Num name="W_mm" label="Width W (mm)" form={form} />
            <Num name="H_mm" label="Height H (mm)" form={form} />
            <Num name="sideSeal_mm" label="Side Seal (mm)" form={form} />
            <Num name="gussetG_mm" label="Gusset G (mm)" form={form} />
            <Num name="zipperAllowance_mm" label="Zipper Allowance (mm)" form={form} />
            <Num name="webWidth_mm" label="Web width (mm)" form={form} />
          </>)}
          {selectedGroup === 'pouch_side_gusset' && (<>
            <Num name="F_mm" label="Front F (mm)" form={form} />
            <Num name="G_mm" label="Gusset G (mm)" form={form} />
            <Num name="H_mm" label="Height H (mm)" form={form} />
            <Num name="bottomAllowance_mm" label="Bottom Allowance (mm)" form={form} />
            <Num name="zipperAllowance_mm" label="Zipper Allowance (mm)" form={form} />
            <Num name="webWidth_mm" label="Web width (mm)" form={form} />
          </>)}
        </form>

        {/* Draft controls */}
        <div className="mt-4 flex flex-wrap items-center gap-2">
          <Button onClick={async ()=>{
            const payload = { jobName, selectedGroup, selectedTemplateId, layers, geometry: form.getValues() }
            const rec = await saveDraft(jobName, payload, currentDraftId ?? undefined)
            setCurrentDraftId(rec.id)
            refreshDrafts()
          }}>Save Draft</Button>

          <select className="rounded border border-neutral-300 px-2 py-1 text-sm" onChange={async (e)=>{
            const id = e.target.value; if (!id) return
            const rec = await loadDraft(id) as any
            if (rec) {
              setJobName(rec.name); setGroup(rec.payload.selectedGroup)
              if (rec.payload.selectedTemplateId) handleChooseTemplate(rec.payload.selectedTemplateId)
              setLayers(rec.payload.layers); form.reset(rec.payload.geometry); setCurrentDraftId(rec.id)
            }
          }}>
            <option value="">Load draft…</option>
            {drafts.map(d => <option key={d.id} value={d.id}>{d.name}</option>)}
          </select>

          {currentDraftId && <Button onClick={async ()=>{ await deleteDraft(currentDraftId!); setCurrentDraftId(null); refreshDrafts() }}>Delete Current</Button>}
        </div>
      </Card>

      {/* Middle: Layers */}
      <LayersCard />

      {/* Right: Results */}
      <ResultsCard tgsm={tgsm} area_m2={area_m2} kg={kg} lm={lm} rm={rm} sell={sell} values={values} selectedGroup={selectedGroup as any} layers={layers} />
    </div>
  )
}

function Num({ name, label, form }:{ name: string; label: string; form: ReturnType<typeof useForm<any>> }){
  const err = (form.formState.errors as any)[name]?.message as string | undefined
  return (
    <div>
      <label className="text-sm text-neutral-700">{label}</label>
      <input className="mt-1 w-full rounded border border-neutral-300 px-2 py-1 text-sm" type="number" step="1" {...form.register(name, { valueAsNumber: true })} />
      {err && <p className="text-xs text-red-600">{err}</p>}
    </div>
  )
}

function LayersCard(){
  const layers = useAppStore(s => s.layers)
  const materials = useAppStore(s => s.materials)
  const setLayers = useAppStore(s => s.setLayers)
  return (
    <Card className="md:col-span-5 p-4">
      <h2 className="mb-3 text-lg font-semibold">2) Layer Stack</h2>
      {!layers.length ? (
        <p className="text-sm text-neutral-500">Choose a template to load layers.</p>
      ) : (
        <table className="w-full text-sm">
          <thead>
            <tr className="text-left text-neutral-600">
              <th className="py-2">Role</th>
              <th>Slot/Type</th>
              <th>Material / GSM</th>
              <th>Thickness (µm)</th>
              <th>Density (g/cc)</th>
              <th>GSM</th>
            </tr>
          </thead>
          <tbody>
            {layers.map((L, idx) => {
              if (L.role === 'SUBSTRATE') {
                const sub = L as any as SubstrateLayer
                return (
                  <tr key={L.id} className="border-t">
                    <td className="py-2 font-medium">SUBSTRATE</td>
                    <td>{sub.slot}</td>
                    <td>
                      <select
                        className="rounded border border-neutral-300 px-2 py-1"
                        value={sub.materialFamily}
                        onChange={(e) => {
                          const fam = e.target.value
                          const density = (materials as any[]).find(m=>m.family===fam)?.density_gcc ?? sub.density_gcc
                          const next = layers.slice()
                          ;(next[idx] as any).materialFamily = fam
                          ;(next[idx] as any).density_gcc = density
                          setLayers(next)
                        }}
                      >
                        {sub.allowedFamilies.map(f => <option key={f} value={f}>{f}</option>)}
                      </select>
                    </td>
                    <td>
                      <input type="number" className="w-24 rounded border border-neutral-300 px-2 py-1"
                        value={sub.thickness_um}
                        onChange={(e)=>{
                          const v = Number(e.target.value)
                          const next = layers.slice(); (next[idx] as any).thickness_um = v; setLayers(next)
                        }}
                        step={1} min={1}
                      />
                    </td>
                    <td>
                      <input type="number" className="w-24 rounded border border-neutral-300 px-2 py-1"
                        value={sub.density_gcc}
                        onChange={(e)=>{
                          const v = Number(e.target.value)
                          const next = layers.slice(); (next[idx] as any).density_gcc = v; setLayers(next)
                        }}
                        step={0.01}
                      />
                    </td>
                    <td className="text-right tabular-nums">{gsmForLayer(L).toFixed(2)}</td>
                  </tr>
                )
              } else {
                const c = L as any as CoatingLayer
                return (
                  <tr key={L.id} className="border-t">
                    <td className="py-2 font-medium">COATING</td>
                    <td>{c.type}</td>
                    <td colSpan={2}>
                      <div className="flex items-center gap-2">
                        <span className="text-neutral-600">GSM</span>
                        <input type="number" className="w-28 rounded border border-neutral-300 px-2 py-1"
                          value={c.gsm}
                          onChange={(e)=>{
                            const v = Number(e.target.value)
                            const next = layers.slice(); (next[idx] as any).gsm = v; setLayers(next)
                          }}
                          step={0.1}
                        />
                      </div>
                    </td>
                    <td className="text-neutral-400">—</td>
                    <td className="text-right tabular-nums">{gsmForLayer(L).toFixed(2)}</td>
                  </tr>
                )
              }
            })}
            <tr className="border-t font-semibold">
              <td className="py-2">Total</td>
              <td colSpan={4}></td>
              <td className="text-right tabular-nums">{layers.reduce((a,l)=>a+gsmForLayer(l),0).toFixed(2)}</td>
            </tr>
          </tbody>
        </table>
      )}
    </Card>
  )
}

function ResultsCard({ tgsm, area_m2, kg, lm, rm, sell }:{ tgsm:number; area_m2:number; kg:number; lm:number; rm:number; sell:number }){
  return (
    <Card className="md:col-span-3 p-4">
      <h2 className="mb-3 text-lg font-semibold">3) Results</h2>
      <ul className="space-y-1 text-sm">
        <li>Total GSM: <b>{tgsm.toFixed(2)}</b></li>
        <li>Area (m²): <b>{area_m2.toFixed(3)}</b></li>
        <li>Weight (kg): <b>{kg.toFixed(2)}</b></li>
        <li>Length (m): <b>{lm.toFixed(1)}</b></li>
        <li>RM Cost: <b>{rm.toFixed(2)}</b></li>
        <li>Price (+margin): <b>{sell.toFixed(2)}</b></li>
      </ul>
      <div className="mt-4 flex gap-2">
        <Button onClick={()=>{
          const blob = new Blob([JSON.stringify({ when: new Date().toISOString(), state: (window as any).__APP_STATE__ || {} }, null, 2)], {type: 'application/json'})
          const url = URL.createObjectURL(blob)
          const a = document.createElement('a')
          a.href = url; a.download = 'estimate.json'; a.click()
          URL.revokeObjectURL(url)
        }}>Export JSON</Button>
      </div>
    </Card>
  )
}
