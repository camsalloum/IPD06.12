import { z } from 'zod'

export const baseQty = z.object({
  quantityMode: z.enum(['pieces','kpcs','sqm','lm','kg']),
  quantityValue: z.number().positive(),
  webWidth_mm: z.number().positive().optional()
})
export const walSchema = baseQty.extend({
  productGroup: z.literal('wal'),
  cutLength_mm: z.number().positive(),
  height_mm: z.number().positive(),
  overlap_mm: z.number().min(0),
  gap_mm: z.number().min(0).optional(),
})
export const sleeveSchema = baseQty.extend({
  productGroup: z.literal('sleeve'),
  layflat_mm: z.number().positive().optional(),
  circumference_mm: z.number().positive().optional(),
  cutHeight_mm: z.number().positive(),
  seamAllowance_mm: z.number().min(0).optional(),
}).refine(d => d.layflat_mm || d.circumference_mm, { path: ['layflat_mm'], message: 'Provide layflat or circumference' })
export const genericSchema = baseQty.extend({
  productGroup: z.enum(['laminate','monolayer']),
  width_mm: z.number().positive(),
  height_mm: z.number().positive(),
  sideSeal_mm: z.number().min(0).optional(),
  bottomSeal_mm: z.number().min(0).optional(),
  overlap_mm: z.number().min(0).optional(),
})
export const pouch3ssSchema = baseQty.extend({
  productGroup: z.literal('pouch_3ss'),
  W_mm: z.number().positive(),
  H_mm: z.number().positive(),
  sideSeal_mm: z.number().min(0),
  bottomSeal_mm: z.number().min(0),
  header_mm: z.number().min(0).optional(),
  zipperAllowance_mm: z.number().min(0).optional(),
})
export const pouchSUPSchema = baseQty.extend({
  productGroup: z.enum(['pouch_sup_doyen','pouch_sup_k']),
  W_mm: z.number().positive(),
  H_mm: z.number().positive(),
  sideSeal_mm: z.number().min(0),
  gussetG_mm: z.number().min(0),
  zipperAllowance_mm: z.number().min(0).optional(),
})
export const pouchSideGussetSchema = baseQty.extend({
  productGroup: z.literal('pouch_side_gusset'),
  F_mm: z.number().positive(),
  G_mm: z.number().positive(),
  H_mm: z.number().positive(),
  bottomAllowance_mm: z.number().min(0).optional(),
  zipperAllowance_mm: z.number().min(0).optional(),
})
