# SCRIPTS — Step-by-step (Cursor friendly)

> Run these in the repo root unless noted.

1) **Install**
```bash
pnpm i
```

2) **Start both servers (web + API)**
```bash
pnpm dev
# Web: http://localhost:5173
# API: http://localhost:8787
```

3) **Build all**
```bash
pnpm build
```

4) **Run API only (production-like)**
```bash
pnpm start
# Serves API on :8787
```

5) **API env (optional Postgres)**
Create `apps/api/.env` with:
```
PORT=8787
PG_URL=postgres://user:pass@host:5432/dbname
```
If `PG_URL` is **not** set, API uses in-memory + JSON defaults.

6) **Capacitor (optional, from apps/web)**
```bash
cd apps/web
npm run build
npm run cap:init
npm run cap:sync
npm run cap:open:ios
npm run cap:open:android
```
