# Flexible Packaging Estimator — Monorepo Starter

This is a **Cursor-ready** starter based on:
- **React + TypeScript + Vite + Tailwind + shadcn/ui** (web)
- **Fastify (TypeScript)** API server (backend)
- **Shared calc-engine** (pure TS) used by both
- **localForage** drafts, **React Hook Form + Zod** validation
- **i18next** ready, **Zustand** store
- Optional **PostgreSQL** via `PG_URL` env; falls back to in-memory/JSON

## Quick start
```bash
pnpm i
pnpm dev
# Web: http://localhost:5173
# API: http://localhost:8787
```

If you prefer npm or yarn, replace `pnpm` accordingly.

See **SCRIPTS.md** inside for step-by-step commands.


## Dashboard
- New **/dashboard** route with sidebar, KPI cards, charts (Recharts), and recent drafts.
- **/estimate** remains the calculation workspace.
- Routing via **react-router-dom**.

