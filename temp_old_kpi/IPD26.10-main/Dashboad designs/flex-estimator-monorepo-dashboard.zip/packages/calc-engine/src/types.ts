export type ProductGroup =
  | 'wal' | 'sleeve' | 'laminate' | 'monolayer'
  | 'pouch_3ss' | 'pouch_sup_doyen' | 'pouch_sup_k' | 'pouch_side_gusset'

export type LayerRole = 'SUBSTRATE' | 'COATING_GSM'

export interface SubstrateLayer {
  id: string
  role: 'SUBSTRATE'
  slot: string
  materialFamily: string
  thickness_um: number
  density_gcc: number
  allowedFamilies: string[]
}

export interface CoatingLayer {
  id: string
  role: 'COATING_GSM'
  type: 'Ink' | 'Adhesive_SB' | 'Adhesive_SL' | 'OPV' | 'HSL'
  gsm: number
}

export type Layer = SubstrateLayer | CoatingLayer

export interface ComponentItem {
  id: string
  name: string
  uom: 'piece' | 'lm' | 'sqm' | 'kpcs'
  pricePerUom: number
  defaultAmount?: number
}

export interface MaterialFamily {
  family: string
  density_gcc: number
  price_kg: number
  presets_um?: number[]
}

export interface MarginRule {
  productGroup: string
  basis: 'pieces' | 'kg'
  min: number
  max: number
  margin_pct: number
}

export interface TemplateDef {
  id: string
  product_group: string
  plies: number
  roles: Array<
    | { role: 'SUBSTRATE'; slot: string; allowed: string[] }
    | { role: 'COATING_GSM'; type: 'Ink' | 'Adhesive_SB' | 'Adhesive_SL' | 'OPV' | 'HSL'; default_gsm: number; editable: boolean }
  >
  bounds?: { thickness_um_min?: number; thickness_um_max?: number }
}

export type AnyGeometry =
  | { productGroup: 'wal'; quantityMode: QtyMode; quantityValue: number; webWidth_mm?: number; cutLength_mm: number; height_mm: number; overlap_mm: number; gap_mm?: number }
  | { productGroup: 'sleeve'; quantityMode: QtyMode; quantityValue: number; webWidth_mm?: number; layflat_mm?: number; circumference_mm?: number; cutHeight_mm: number; seamAllowance_mm?: number }
  | { productGroup: 'laminate' | 'monolayer'; quantityMode: QtyMode; quantityValue: number; webWidth_mm?: number; width_mm: number; height_mm: number; sideSeal_mm?: number; bottomSeal_mm?: number; overlap_mm?: number }
  | { productGroup: 'pouch_3ss'; quantityMode: QtyMode; quantityValue: number; webWidth_mm?: number; W_mm: number; H_mm: number; sideSeal_mm: number; bottomSeal_mm: number; header_mm?: number; zipperAllowance_mm?: number }
  | { productGroup: 'pouch_sup_doyen' | 'pouch_sup_k'; quantityMode: QtyMode; quantityValue: number; webWidth_mm?: number; W_mm: number; H_mm: number; sideSeal_mm: number; gussetG_mm: number; zipperAllowance_mm?: number }
  | { productGroup: 'pouch_side_gusset'; quantityMode: QtyMode; quantityValue: number; webWidth_mm?: number; F_mm: number; G_mm: number; H_mm: number; bottomAllowance_mm?: number; zipperAllowance_mm?: number }

export type QtyMode = 'pieces' | 'kpcs' | 'sqm' | 'lm' | 'kg'
