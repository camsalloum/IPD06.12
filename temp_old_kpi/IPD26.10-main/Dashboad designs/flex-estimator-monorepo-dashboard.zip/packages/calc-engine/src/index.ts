import { AnyGeometry, Layer, MarginRule } from './types'

export * from './types'

export function gsmForLayer(layer: Layer): number {
  if (layer.role === 'SUBSTRATE') {
    return layer.thickness_um * layer.density_gcc * 0.1
  } else {
    return layer.gsm
  }
}

export function totalGSM(layers: Layer[]): number {
  return layers.reduce((acc, L) => acc + gsmForLayer(L), 0)
}

export function areaPerPiece_m2(geo: AnyGeometry): number {
  switch (geo.productGroup) {
    case 'wal': {
      const { cutLength_mm, height_mm, overlap_mm } = geo
      return ((cutLength_mm + overlap_mm) * height_mm) / 1_000_000
    }
    case 'sleeve': {
      const { layflat_mm, circumference_mm, cutHeight_mm } = geo
      const width_mm = layflat_mm ?? (circumference_mm ? circumference_mm / 2 : 0)
      return (width_mm * cutHeight_mm) / 1_000_000
    }
    case 'laminate':
    case 'monolayer': {
      const { width_mm, height_mm, sideSeal_mm = 0, bottomSeal_mm = 0, overlap_mm = 0 } = geo as any
      return ((width_mm + 2 * sideSeal_mm + overlap_mm) * (height_mm + bottomSeal_mm)) / 1_000_000
    }
    case 'pouch_3ss': {
      const { W_mm, H_mm, sideSeal_mm, bottomSeal_mm, header_mm = 0, zipperAllowance_mm = 0 } = geo
      return ((W_mm + 2 * sideSeal_mm) * (H_mm + bottomSeal_mm + header_mm + zipperAllowance_mm)) / 1_000_000
    }
    case 'pouch_sup_doyen':
    case 'pouch_sup_k': {
      const { W_mm, H_mm, sideSeal_mm, gussetG_mm, zipperAllowance_mm = 0 } = geo
      return ((W_mm + 2 * sideSeal_mm) * (H_mm + zipperAllowance_mm) + W_mm * gussetG_mm) / 1_000_000
    }
    case 'pouch_side_gusset': {
      const { F_mm, G_mm, H_mm, bottomAllowance_mm = 0, zipperAllowance_mm = 0 } = geo
      const tubeWidth = F_mm + 2 * G_mm
      return (tubeWidth * (H_mm + bottomAllowance_mm + zipperAllowance_mm)) / 1_000_000
    }
  }
}

export function totalArea_m2(geo: AnyGeometry): number {
  const a = areaPerPiece_m2(geo)
  const { quantityMode, quantityValue, webWidth_mm } = geo as any
  switch (quantityMode) {
    case 'pieces': return a * quantityValue
    case 'kpcs': return a * quantityValue * 1000
    case 'sqm': return quantityValue
    case 'lm': return quantityValue * ((webWidth_mm ?? 0) / 1000)
    case 'kg': return 0
  }
}

export function kgFromArea(area_m2: number, total_gsm: number): number {
  return (area_m2 * total_gsm) / 1000
}

export function lengthFromKg(kg: number, total_gsm: number, webWidth_mm: number): number {
  if (total_gsm <= 0 || webWidth_mm <= 0) return 0
  return (kg * 1_000_000) / (total_gsm * webWidth_mm)
}

export function kgFromLength(length_m: number, total_gsm: number, webWidth_mm: number): number {
  return (length_m * total_gsm * webWidth_mm) / 1_000_000
}

export function perLayerKg(layers: Layer[], totalKg: number): { id: string; kg: number; gsm: number; role: string }[] {
  const tgsm = totalGSM(layers)
  return layers.map(L => ({
    id: 'id' in L ? (L as any).id : Math.random().toString(36).slice(2),
    kg: tgsm > 0 ? (totalKg * gsmForLayer(L)) / tgsm : 0,
    gsm: gsmForLayer(L),
    role: L.role
  }))
}

export function rmCost(kgSplit: { kg: number; id: string }[], layers: Layer[], priceByFamily: Record<string, number>, coatingPricePerKg = 0): number {
  let total = 0
  for (let i = 0; i < layers.length; i++) {
    const L = layers[i]
    const kg = kgSplit[i]?.kg ?? 0
    if (L.role === 'SUBSTRATE') {
      const price = priceByFamily[(L as any).materialFamily] ?? 0
      total += kg * price
    } else {
      total += kg * coatingPricePerKg
    }
  }
  return total
}

export function marginPrice(rm: number, rules: MarginRule[], productGroup: string, basis: 'pieces' | 'kg', qtyValue: number): number {
  const rule = rules.find(r => r.productGroup === productGroup && r.basis === basis && qtyValue >= r.min && qtyValue < r.max)
  const pct = rule?.margin_pct ?? 0
  return rm * (1 + pct / 100)
}
